/***
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar 
***/
package learnKotlin

//_____________________________________________________________________

// In Java
//		Clasess Are Open By Default
//			Can Be Inherited From
//		Member Functions Are Also Open By Default
//			Can Be Overridden

// In Kotlin
//		Clasess Are Final By Default
//			Can't Be Inherited From
//		Member Functions Are Also Final By Default
//			Can't Be Overridden
//		override Keyword Required To Override Parent Class Function

open class View {
	open fun click() 	= println("View Clicked!")
}

// Inheritance : Button Inheriting From View Class
class Button : View() {
	override fun click() 	= println("Button Clicked!")
	fun magic() 			= println("Button Magic...")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
	button.magic()

	val viewAgain: View = Button()
	viewAgain.click()
	// error: unresolved reference: magic
	// viewAgain.magic() // Step Motherly Treatment Given To magic Function

	// viewAgain = button
	val letBringKiduBack = viewAgain as Button
	letBringKiduBack.magic()
}

//_____________________________________________________________________
//In Java
	// Employee e = new Employee("Gabbar Singh", 50000 );

// In C/C++
	// Empoloyee *e = ( Employee * ) malloc( sizeof( Employee ) );
	// e -> name 	= "Gabbar Singh";
	// e -> salary  = 50000; 

//_____________________________________________________________________

// Extension Functions
//		doMagic() Is An Extension Function On String Type
fun String.doMagic() {
	println("Adding Magic To String Class...")
}

// Functions Taking String Type Argument and Returing Char Type Value
fun lastCharacter( string: String ) : Char = string.get( string.length  - 1 )

// Extension Functions
//		lastCharacterExt() Is An Extension Function On String Type
//		Returing Char Type Value
fun String.lastCharacterExt() : Char = this.get( this.length  - 1 )

fun playWithStringExtenstionFunctions() {
	val greeting = "Good Evening!"

	greeting.doMagic()

	println( lastCharacter( "Good Evening!" ) )
	println( lastCharacter( "Flat Number #4569" ) )

	println( "Good Evening!".lastCharacterExt() )
	println( "Flat Number #4569".lastCharacterExt() )
}

//_____________________________________________________________________

open class View1 {
	open fun click() 	= println("View1 Clicked!")
}

// Inheritance : Button1 Inheriting From View1 Class
class Button1 : View1() {
	override fun click() 	= println("Button1 Clicked!")
	fun doMagig() 			= println("Button1 Magic..!")
}

fun View1.showOff() 	= println("View1 ShowOff Called...")
fun Button1.showOff() 	= println("Button1 ShowOff Called...")

fun playWithExtensionFunctions() {
	val view = View1()
	view.click()
	view.showOff()
	val button = Button1()
	button.click()
	button.showOff()

	val viewObject : View1 = Button1()
	viewObject.click()
	// viewObject.doMagic()
	// Extension Functions Doesn't Participate In Overriding
	viewObject.showOff()
}


//_____________________________________________________________________

// Abstract Types
//		Cann't Create Instances Of It
// 		Tells What To Do!
interface Clickable2 {
	fun click()
}

// Concrete Class
//		Implements Abstract Types e.g. Interfaces
//		Tells How/When/Which/Where To Do?
class Button21 : Clickable2 {
	override fun click() = println("Button21 Click Called!")
}

// Concrete Class
//		Implements Abstract Types e.g. Interfaces
//		Tells How/When/Which/Where/Why To Do?
class Button22 : Clickable2 {
	override fun click() = println("Button22 Click Called!")
}

fun playWithInterfaces() {
	// error: interface Clickable does not have constructors
	// val click = Clickable()

	val button1 = Button21()
	button1.click()

	val button2 = Button22()
	button2.click()
}

//_____________________________________________________________________

interface Clickable3 {
	fun click()
	fun showOff() = println("Clickable3 Interface showOff Function")
}

interface Focusable3 {
	fun setFocus( status: Boolean ) = println( "I ${ if (status) "GOT" else "LOST" } FOCUS." )
	fun showOff() = println("Focusable3 Interface showOff Function")
}

// Concrete Class
//		Implements Abstract Types e.g. Interfaces
//		Tells How/When/Which/Where/Why To Do?
class Button3 : Clickable3, Focusable3 {
	override fun click() 	= println("Button3 Click Called!")
	override fun showOff() {
		println("Button3 showOff Called!")
		// super.showOff()
		// Custom Logic Will Go Here...
		super<Clickable3>.showOff()
		super<Focusable3>.showOff()
	}
}

fun playWithInterfacesAgain() {
	val button1 = Button3()
	button1.click()
	button1.setFocus( true )
	button1.showOff()

	val button2 = Button3()
	button2.click()
	button2.setFocus( false )
	button2.showOff()
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithInheritance")
	playWithInheritance()

	println("\nFunction: playWithStringExtenstionFunctions")
	playWithStringExtenstionFunctions()

	println("\nFunction: playWithExtensionFunctions")
	playWithExtensionFunctions()

	println("\nFunction: playWithInterfaces")
	playWithInterfaces()

	println("\nFunction: playWithInterfacesAgain")
	playWithInterfacesAgain()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
