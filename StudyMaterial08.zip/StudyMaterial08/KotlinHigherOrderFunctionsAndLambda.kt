/***
kotlinc KotlinHigherOrderFunctionsAndLambda.kt -include-runtime -d hoflambda.jar
java -jar hoflambda.jar 
***/
package learnKotlin

//_____________________________________________________________________

// Function Type
//		(Int, Int) -> Int
fun sum( x: Int, y: Int ) : Int = x + y
fun sub( x: Int, y: Int ) : Int = x - y
fun mul( x: Int, y: Int ) : Int = x * y

// Polymorphic Function
//		Using Mechanism 
//			By Passing Function To Function
//			OR Passing A Behviour To Behaviour
fun calculator( x: Int, y: Int, operation: (Int, Int) -> Int ) : Int {
	return operation(x, y)
}

fun playWithCalculator() {
	val a = 200;
	val b = 100;
	var result: Int;

	result = calculator( a, b, ::sum )
	println("Result : $result")

	result = calculator( a, b, ::sub )
	println("Result : $result")

	result = calculator( a, b, ::mul )
	println("Result : $result")
	// Lamda Expression Having Function Type (Int, Int) -> Int
	//		Takes Two Arguments Of Int Type and Return Value Of Int Type
	val sumLambda: (Int, Int) -> Int = { x: Int, y: Int -> x + y }
	result = calculator( a, b, sumLambda )
	println("Result : $result")

	val subLambda: (Int, Int) -> Int = { x: Int, y: Int -> x - y }
	result = calculator( a, b, subLambda )
	println("Result : $result")

	val mulLambda = { x: Int, y: Int -> x * y }
	result = calculator( a, b, mulLambda )
	println("Result : $result")

	result = calculator( a, b, { x: Int, y: Int -> x + y } )
	println("Result : $result")

	result = calculator( a, b, { x: Int, y: Int -> x - y } )
	println("Result : $result")

	val something = ::sum // :: Used To Get Reference Of sum Function
	result = something( 900, 100 )
	println("Result : $result")	

	val something1: (Int, Int) -> Int  = ::sum // :: Used To Get Reference Of sum Function
	result = something1( 900, 100 )
	println("Result : $result")	

	val somethingAgain = ::calculator
	result = somethingAgain( 900, 100, ::sum )
	println("Result : $result")	

	val somethingAgain1 : (Int, Int, (Int,Int) -> Int) -> Int = ::calculator
	result = somethingAgain1( 900, 100, ::sum )
	println("Result : $result")	
}

//_____________________________________________________________________

data class Person(val name: String, val age: Int, val height: Double ) 

fun findTheOldest( persons : List<Person> ) : Person? {
	var maxAge = 0
	var theOldest : Person? = null

	for( person in persons ) {
		if ( person.age > maxAge ) {
			maxAge 		= person.age
			theOldest 	= person
		}
	}
	return theOldest
}

fun playWithThePersons() {
	val persons = listOf(
		Person( "Gabbar Singh", 30, 5.5 ), Person( "Basanti Only", 22, 5.2 ), Person( "Veeru", 30, 6.0 ),
		Person( "Thakur", 50, 5.5 ), Person( "Radha", 32, 5.6 ), Person( "Mausi",  80, 5.1 ), 
		Person( "Jay", 28, 6.4 ),
	)

	println( findTheOldest( persons ) )
}

//_____________________________________________________________________

data class Person1( val name: String, val profile: String, val title: String ) 

fun playWithtLambdas() {
	val something: () -> Unit = { println(4000) }
	something()

	val persons = listOf(
		Person1( "Gabbar Singh", "Decoit", "Mr." ), Person1( "Basanti Only", "Heroine", "Mrs." ), 
		Person1( "Veeru", "Hero", "Mr." ), Person1( "Thakur", "Gang Master", "Mr." ), 
		Person1( "Radha", "Heroin", "Mrs." ), Person1( "Mausi",  "Propsective Mother In Law", "Mrs." ), 
		Person1( "Jay", "Hero", "Mr." ),
	)

	val names = persons.joinToString( separator = "  ", 
									  transform = { person: Person1 -> person.name } )	
	println( names )

	val titles = persons.joinToString( separator = " : ", 
									  transform = { person: Person1 -> person.title } )	
	println( titles )

	val profiles = persons.joinToString( separator = " : ", 
									  transform = { person: Person1 -> person.profile } )	
	println( profiles )

	var result : Int
	var multiplyLambda: (Int, Int) -> Int 
	multiplyLambda = { a: Int, b: Int -> a * b }

	result = multiplyLambda( 50, 10 )
	println( result )

	multiplyLambda = { a: Int, b: Int -> Int 
		a * b 
	}
	result = multiplyLambda( 60, 10 )
	println( result )

	multiplyLambda = { a, b -> 
		a * b 
	}
	result = multiplyLambda( 70, 10 )
	println( result )

	var doubleLambda = { a : Int -> 2 * a }
	result = doubleLambda( 11 )
	println( result )

	doubleLambda = { a : Int -> 
		2 * a 
	}
	result = doubleLambda( 11 )
	println( result )

	doubleLambda = { 
		2 * it 
	}
	result = doubleLambda( 22 )
	println( result )

	doubleLambda = { 2 * it }
	result = doubleLambda( 33 )
	println( result )

	val square1 = { number : Int -> number * number }
	result = square1( 25 )
	println( result )

	// val square2 = { it * it }
	val square2: (Int) -> Int  = { it * it }
	result = square2( 25 )
	println( result )
}

//_____________________________________________________________________

fun playWithtLambdasAgain() {
	var result: Int

	fun operate( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
		val result1 = operation( a, b )
		return result1
	}

	val addLambda = { a: Int, b: Int -> a + b }
	result = operate( 40, 20, operation = addLambda )
	println( result )

	fun addFunction( a: Int, b: Int ) = a + b 
	result = operate( 40, 20, operation = ::addFunction )
	println( result )

	result = operate( 40, 20, operation = Int::plus )
	println( result )

	result = operate( 40, 20, operation =  { a: Int, b: Int -> a + b } )
	println( result )

	result = operate( 40, 20, 
		operation =  { a: Int, b: Int -> 
			a + b 
		} 
	)
	println( result )

	result = operate( 40, 20, 
		operation =  { a, b -> 
			a + b 
		} 
	)
	println( result )

	result = operate( 40, 20, operation =  { a, b -> a + b } )
	println( result )

	result = operate( 40, 20, { a, b -> a + b } )
	println( result )

	// Trailing Lambda Syntax
	result = operate( 40, 20 ) { a, b -> a + b } 
	println( result )

	result = operate( 40, 20 ) { // Extended Logic Extending Operate Function Logic
		a, b -> a + b 
	} 
	println( result )
}

//_____________________________________________________________________

// Higher Order Function
//		Functions Which Takes And/Or Returns Functions

fun chooseSteps( backward: Boolean ) : (Int) -> Int {
	fun moveForward( start : Int ) : Int  { return start + 1 }
	fun moveBackward( start : Int ): Int  { return start + 1 }

	return if ( backward ) ::moveBackward else ::moveForward
}

fun playWithChooseStepFunction() {
	// (Boolean) -> (Int -> Int)
	// (Boolean) -> Int 
	// (Boolean, Int)-> Int
	// (Int) -> Int
	val something : (Int) -> Int  = chooseSteps( backward = true )
	var result = something( 10 )
	println( result )

	val somethingAgain : (Boolean) -> (Int) -> Int = ::chooseSteps
	val resultAgain : (Int) -> Int = somethingAgain( true )
	println( result )
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: playWithThePersons")
	playWithThePersons()

	println("\nFunction: playWithtLambdas")
	playWithtLambdas()

	println("\nFunction: playWithtLambdasAgain")
	playWithtLambdasAgain()

	println("\nFunction: playWithChooseStepFunction")
	playWithChooseStepFunction()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
