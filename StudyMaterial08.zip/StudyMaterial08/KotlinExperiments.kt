
package learnKotlin;

class ShapeBetter( val boundaryColor : Colour = Colour.BLACK, val fillColor : Colour = Colour.WHITE ) {
	override fun toString() = "Shape(boundaryColor=$boundaryColor, fillColor=$fillColor)"
}

fun playWithShapeBetter() {
	val shape1 = ShapeBetter( Colour.RED )
	val shape2 = ShapeBetter( Colour.RED, Colour.GREEN )

	println( shape1 )
	println( shape2 )

	val shape3 = ShapeBetter( )
	val shape4 = ShapeBetter( boundaryColor = Colour.RED, fillColor = Colour.GREEN )
	val shape5 = ShapeBetter( fillColor = Colour.GREEN, boundaryColor = Colour.RED )
	val shape6 = ShapeBetter( fillColor = Colour.GREEN )
	val shape7 = ShapeBetter( boundaryColor = Colour.RED )
	
	println( shape3 )
	println( shape4 )
	println( shape5 )
	println( shape6 )
	println( shape7 )
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main() {
	playWithShapeBetter()
}