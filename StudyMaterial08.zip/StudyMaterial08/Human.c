
#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human ;

void bhangraDance() {
	printf("\nDoing Bhangraa... Ballleeee Balllleeeee!!!");
}

void bharatnatyamDance() {
	printf("\nBharat Natayaam... Eye and Hands Moments!!!");
}

void playWithHuman() {
	Human gabbar = { 420, "Gabbar Singh", bhangraDance };
	printf("\nID: %d", gabbar.id );
	printf("\nName: %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti Only", bharatnatyamDance };
	printf("\nID: %d", basanti.id );
	printf("\nName: %s", basanti.name );
	basanti.dance();
}

int main() {
	playWithHuman();
}
