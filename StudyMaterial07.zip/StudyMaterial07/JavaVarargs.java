/*
// Compilating Java Code 
javac JavaVarargs.java -d ClassFiles

// Running Java Code
java -cp ClassFiles/ learnJava.JavaVarargs
*/
package learnJava;

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

public class JavaVarargs {

    public static int average( int... numbers ) {
        int total = 0;

        for ( int number : numbers ) {
            total = total + number;
        }

        return total / numbers.length;
    }

	public static void main( String [] args ) {
		System.out.println("\nFunction : average ");
        System.out.println( average( 10 ));        
        System.out.println( average( 10, 20, 30 ));
        System.out.println( average( 10, 20, 30, 40, 50, 60 ));
		// System.out.println("\nFunction : ");
	}
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/

