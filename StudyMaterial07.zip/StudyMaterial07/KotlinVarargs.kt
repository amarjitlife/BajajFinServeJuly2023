/***
kotlinc KotlinVarargs.kt -include-runtime -d varargs.jar
java -jar varargs.jar 
***/
package learnKotlin

//_____________________________________________________________________

fun average( vararg numbers: Int ) : Int {
	var total = 0
	var count = 0
	for ( number in numbers ) {
		count = count + 1
		total = total + number
	}

	return total / count
}

fun playWithAverage() {
	println("Average : ${ average(10) }")
	println("Average : ${ average(10, 20, 30) }")
	println("Average : ${ average(10, 20, 30, 40, 50, 60) }")
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main( args: Array<String> ) {
	for ( arg in args ) {
		println("Argument Supplied : $arg")	
	}

	println("\nFunction: playWithAverage")
	playWithAverage()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
