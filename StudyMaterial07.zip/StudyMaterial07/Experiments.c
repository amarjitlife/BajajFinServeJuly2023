#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <stdarg.h>

//__________________________________________________________

// DESIGN 01
// Write Following sum Function In C
int sum(int x, int y) {
	return x + y;
}

//__________________________________________________________

void playWithSum() {
	int result = 0, a, b;

	a = 2147483647;
	b = 10;
	result = sum(a, b);
	printf("\nResult : %d", result);

	a = -2147483648;
	b = -10;
	result = sum(a, b);
	printf("\nResult : %d", result);	
}
// Result : -2147483639
// Result : 214748363

// DESIGN 02
// Write Following sum Function In C
// 	It Should Returns Valid Arithmetic Sum Of x And y
// 	Otherwise Print Can't Calculate Sum For Given x And y

// 	int sum(int x, int y) {

// 	}

//__________________________________________________________ 

// #include <limits.h>
int summation( int a, int b ) {
	int result = 0;

	if ( ( ( b > 0 ) && ( a > ( INT_MAX - b) ) ) || 
		 ( ( b < 0 ) && ( a < ( INT_MIN - b )) ) ) {
		 	printf("\nCan't Calculate Sum For Given a And b");
		 	exit(1);
	} else {
		result = a + b;

	}
	return result;
}

//__________________________________________________________ 
/*
A. CTE
B. RTE 
C. 10 20 30 40 50
D. None Of These
*/

//__________________________________________________________

void playWithArrays() {
	char * username;
	char *password;
	int i = 0;
	int a[5] = { 10, 20, 30, 40, 50 };

	printf("\n");
	for ( int i = 0 ; i < 10 ; i++ ) {
		printf("\t %d", a[i] );
	}
}

//__________________________________________________________

void playWithAuthentication() {
	char * username;
	char *password;
	int i = 0;
	int a[5] = { 10, 20, 30, 40, 50 };

	printf("\n");
	for ( int i = 0 ; i < 10 ; i++ ) {
		printf("\t %d", a[i] );
	}

	// k = sum(a, b);
	// printf("\n %d", a[k] );
}

//__________________________________________________________

void playWithIfElse() {
	int a = 10;
	int b = 20;
	int result = 0;

	if ( a > b ) {
		result = a;
	}
	else {
		result = b;
	}

	// result = if ( a > b ) a else b

	//OR
	result = ( a > b ) ? a : b ;
}

//__________________________________________________________

// int average( int... values ) {
// 	int result = 0;

// 	for ( int i = 0 ; i < )
// }

// #include <stdio.h>
// #include <stdarg.h>

double average(int num, ...) {
   va_list valist;
   double sum = 0.0;
   int i;

   /* initialize valist for num number of arguments */
   va_start(valist, num);

   /* access all the arguments assigned to valist */
   for (i = 0; i < num; i++) {
      sum += va_arg(valist, int);
   }
	
   /* clean memory reserved for valist */
   va_end(valist);

   return sum/num;
}

void playWithAverage() {
	printf("\nAverage : %f", average(10));
	printf("\nAverage : %f", average(10, 20));
	printf("\nAverage : %f", average(10, 20, 30, 40));
	printf("\nAverage : %f", average(10, 20, 30, 40, 50));
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

int main( int argc, char *argv[] ) {
	printf("\nArugments Count: %d", argc );
	// for ( int i = 0; i < argc ; i++ ) {
	for ( int i = 1 ; i < argc ; i++ ) {
		printf("\nArugments Supplied: %s", argv[i] );
	}

	// if ( argv[1] == "-l" )  {
	// 	// Do Something
	// } else if ( argv[2] == "-a") {
	// 	// Do Something Else 
	// }

	printf("\n\nFunction : playWithSum");
	playWithSum();

	printf("\n\nFunction : playWithArrays");
	playWithArrays();

	printf("\n\nFunction : playWithAuthentication");
	playWithAuthentication();

	printf("\n\nFunction : playWithAverage");
	playWithAverage();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");	
}

