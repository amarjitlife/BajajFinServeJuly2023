/***
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar 
***/
package learnKotlin

//_____________________________________________________________________

// In Java
//		Clasess Are Open By Default
//			Can Be Inherited From
//		Member Functions Are Also Open By Default
//			Can Be Overridden

// In Kotlin
//		Clasess Are Final By Default
//			Can't Be Inherited From
//		Member Functions Are Also Final By Default
//			Can't Be Overridden
//		override Keyword Required To Override Parent Class Function

open class View {
	open fun click() 	= println("View Clicked!")
}

// Inheritance : Button Inheriting From View Class
class Button : View() {
	override fun click() 	= println("Button Clicked!")
	fun magic() 			= println("Button Magic...")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
	button.magic()

	val viewAgain: View = Button()
	viewAgain.click()
	// error: unresolved reference: magic
	// viewAgain.magic() // Step Motherly Treatment Given To magic Function

	// viewAgain = button
	val letBringKiduBack = viewAgain as Button
	letBringKiduBack.magic()
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithInheritance")
	playWithInheritance()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
