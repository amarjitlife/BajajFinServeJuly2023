// Compilating Java Code 
// javac JavaObjectOrientedProgramming.java -d ClassFiles

// Running Java Code
// java -cp ClassFiles/ learnJava.JavaObjectOrientedProgramming

package learnJava;

import java.time.DayOfWeek;
import java.time.LocalDate;

//_____________________________________________________________________

class Cal {
    public static void playWithCalender(String [] args) {
        LocalDate date = LocalDate.now().withDayOfMonth(1);
        int month;
        if (args.length >= 2) {        
            month = Integer.parseInt(args[0]);
            int year = Integer.parseInt(args[1]);
            date = LocalDate.of(year, month, 1);
        } else {
            month = date.getMonthValue();
        }
        
        System.out.println(" Mon Tue Wed Thu Fri Sat Sun");
        DayOfWeek weekday = date.getDayOfWeek();
        int value = weekday.getValue(); // 1 = Monday, ... 7 = Sunday
        for (int i = 1; i < value; i++) 
            System.out.print("    ");
        while (date.getMonthValue() == month) {
            System.out.printf("%4d", date.getDayOfMonth());
            date = date.plusDays(1);
            if (date.getDayOfWeek().getValue() == 1) 
                System.out.println();
        }
        if (date.getDayOfWeek().getValue() != 1) 
           System.out.println();
    }
}

//_____________________________________________________________________

class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

class EmployeeDemo {
    public static void playWithEmployee() {
        Employee gabbar = new Employee("Gabbar Singh", 50000);
        gabbar.raiseSalary(50000);
        System.out.println( gabbar.getName());
        System.out.println( gabbar.getSalary());
    }
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

public class JavaObjectOrientedProgramming {
	public static void main( String [] args ) {
		System.out.println("\n\nFunction : playWithCalender");
		Cal.playWithCalender(args);

		System.out.println("\n\nFunction : playWithEmployee");
		EmployeeDemo.playWithEmployee();

		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
	}
}
/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/

