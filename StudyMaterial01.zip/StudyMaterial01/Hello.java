// Compiling Java Program Hello.java
// javac Hello.java

// Running Java Program
// java Hello

class Hello {
	public static void main(String []args ) {
		System.out.println("Hello World!");
	}
}

