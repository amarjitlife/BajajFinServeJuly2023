// Compilating Java Code 
// javac JavaInhertiance.java -d ClassFiles

// Running Java Code
// java -cp ClassFiles/ learnJava.JavaInheritance

package learnJava;

//_____________________________________________________________________

class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;
    }
    
    public final String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

// Inheritance
class Manager extends Employee {
    private double bonus;
    
    public Manager(String name, double salary) {
        super(name, salary);
        bonus = 0;
    }
    
    public void setBonus(double bonus) {
        this.bonus = bonus;
    }
    
    public double getSalary() { // Overrides superclass method
        return super.getSalary() + bonus;
    }
} 

class InheritanceDemo {
    public static void playWithInheritance() {
        Manager boss = new Manager("Fred", 200000);
        boss.setBonus(10000); // Defined in subclass
        System.out.println(boss.getSalary());
        boss.raiseSalary(5); // Inherited from superclass
        System.out.println(boss.getSalary());        
        
        Employee empl = boss; // Ok to convert to superclass
        empl.raiseSalary(5); // Can still apply superclass methods
        System.out.println(empl.getSalary()); // Calls Manager.getSalary
        
        if (empl instanceof Manager) {
            Manager mgr = (Manager) empl;
            mgr.setBonus(20000);
        }
    }
}

//_____________________________________________________________________

abstract class Person {
    private String name;

    public Person(String name) { this.name = name; }
    public final String getName() { return name; }

    public abstract int getId();
}

interface Named {
    default String getName() { return ""; }
}

class Student extends Person implements Named {
    private int id;

    public Student(String name, int id) { super(name); this.id = id; }
    // public int getId() { return id; }
}

class StudentDemo {
    public static void playWithStudent() {
        Person p = new Student("Fred", 1729); // OK, a concrete subclass
        System.out.println(p.getName());
        Student s = (Student) p;
        System.out.println(s.getName());
        Named n = s;
        System.out.println(n.getName());
    }
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

public class JavaInheritance {
	public static void main( String [] args ) {
        System.out.println("\n\nFunction : playWithInheritance");
        InheritanceDemo.playWithInheritance();

        System.out.println("\n\nFunction : playWithStudent");
        StudentDemo.playWithStudent();

        // System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
	}
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/

