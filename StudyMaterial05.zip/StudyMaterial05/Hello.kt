/***
kotlinc Hello.kt -include-runtime -d hello.jar
java -jar hello.jar 
***/
package learnKotlin

fun helloWorld() {
	println("Hello World!");
}

fun main() {
	println("\n\nFunction: helloWorld")
	helloWorld()	

	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
}
