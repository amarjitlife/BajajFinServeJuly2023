/***
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar 
***/
package learnKotlin


//_____________________________________________________________________
//In Java
	// Employee e = new Employee("Gabbar Singh", 50000 );

// In C/C++
	// Empoloyee *e = ( Employee * ) malloc( sizeof( Employee ) );
	// e -> name 	= "Gabbar Singh";
	// e -> salary  = 50000; 

//_____________________________________________________________________

// Extension Functions
//		doMagic() Is An Extension Function On String Type
fun String.doMagic() {
	println("Adding Magic To String Class...")
}

// Functions Taking String Type Argument and Returing Char Type Value
fun lastCharacter( string: String ) : Char = string.get( string.length  - 1 )

// Extension Functions
//		lastCharacterExt() Is An Extension Function On String Type
//			Returing Char Type Value
fun String.lastCharacterExtension() : Char = this.get( this.length  - 1 )

fun playWithStringExtenstionFunctions() {
	val greeting = "Good Evening!"

	greeting.doMagic()

	println( lastCharacter( "Good Evening!" ) )
	println( lastCharacter( "Flat Number #4569" ) )

	println( "Good Evening!".lastCharacterExtension() )
	println( "Flat Number #4569".lastCharacterExtension() )
}

//_____________________________________________________________________

fun playWithKotlinCollections() {
	val set = hashSetOf(1, 7, 53) 
	val list = arrayListOf(1, 7, 53) 
	val map = hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println(set.javaClass)
    println(list.javaClass)
    println(map.javaClass)

    val strings = listOf("first", "second", "fourteenth")
    println(strings.javaClass)
    println(strings.last())
    val numbers = setOf(1, 14, 2)
    println(numbers.javaClass)
    //println(numbers.max())
    println(numbers.maxOrNull())
}
// Function: playWithKotlinCollections
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// class java.util.Arrays$ArrayList
// fourteenth
// class java.util.LinkedHashSet
// 14

//_____________________________________________________________________

fun joinToString(
	collection : ArrayList<String>,
	seperator : String,
	prefix : String,
	postfix : String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" )
	println( joinToString( names, " : ", " ( ", " ) " ) )
	println( joinToString( names, " #### ", " [[[ ", " ]]] " ) )

	// val numbers = arrayListOf( 100, 200, 300, 400, 500 )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	// println( joinToString( numbers, " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	// println( joinToString( numbers, " #### ", " [[[ ", " ]]] " ) )
}

//_____________________________________________________________________

fun joinToStringWithDefault(
	collection : ArrayList<String>,
	seperator : String = " ",
	prefix : String = "",
	postfix : String = ""
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringWithDefaults() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" )
	println( joinToStringWithDefault( names, " : ", " ( ", " ) " ) )
	println( joinToStringWithDefault( names ) )
	println( joinToStringWithDefault( names, " : " ) )
	println( joinToStringWithDefault( names, " : ", " ( " ) )
	println( joinToStringWithDefault( names, " : ", " ( ", " ) " ) )

	println( joinToStringWithDefault( names, " #### ", " [[[ ", " ]]] " ) )
	println( joinToStringWithDefault( names ) )
	println( joinToStringWithDefault( names, " #### " ) )
	println( joinToStringWithDefault( names, " #### ", " [[[ " ) )
	println( joinToStringWithDefault( names, " #### ", " [[[ ", " ]]] " ) )

	// val numbers = arrayListOf( 100, 200, 300, 400, 500 )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	// println( joinToString( numbers, " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	// println( joinToString( numbers, " #### ", " [[[ ", " ]]] " ) )
}

//_____________________________________________________________________

fun <E> joinToStringWithDefaultAndGenerics(
	collection : Collection<E>,
	seperator : String = " ",
	prefix : String = "",
	postfix : String = ""
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringWithDefaultsAndGenerics() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" ) // ArrayList<String>
	println( names.javaClass )
	println( joinToStringWithDefaultAndGenerics( names, " : ", " ( ", " ) " ) )
	println( joinToStringWithDefaultAndGenerics( names ) )
	println( joinToStringWithDefaultAndGenerics( names, " : " ) )
	println( joinToStringWithDefaultAndGenerics( names, " : ", " ( " ) )
	println( joinToStringWithDefaultAndGenerics( names, " : ", " ( ", " ) " ) )

	println( joinToStringWithDefaultAndGenerics( names, " #### ", " [[[ ", " ]]] " ) )
	println( joinToStringWithDefaultAndGenerics( names ) )
	println( joinToStringWithDefaultAndGenerics( names, " #### " ) )
	println( joinToStringWithDefaultAndGenerics( names, " #### ", " [[[ " ) )
	println( joinToStringWithDefaultAndGenerics( names, " #### ", " [[[ ", " ]]] " ) )

	val numbers = arrayListOf( 100, 200, 300, 400, 500 ) // ArrayList<Int>
	println( numbers.javaClass )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( joinToStringWithDefaultAndGenerics( numbers, " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( joinToStringWithDefaultAndGenerics( numbers, " #### ", " [[[ ", " ]]] " ) )

    val strings = listOf("first", "second", "fourteenth")
	println( joinToStringWithDefaultAndGenerics( strings, " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( joinToStringWithDefaultAndGenerics( strings, " #### ", " [[[ ", " ]]] " ) )
}

//_____________________________________________________________________
// Extention Function
//		joinToStringExtension() Extension Function On Type Collection<E>

fun <E> Collection<E>.joinToStringExtension(
	// collection : Collection<E>,
	seperator : String = " ",
	prefix : String = "",
	postfix : String = ""
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" ) // ArrayList<String>
	println( names.javaClass )
	println( names.joinToStringExtension( " : ", " ( ", " ) " ) )
	println( names.joinToStringExtension( ) )
	println( names.joinToStringExtension( " : " ) )
	println( names.joinToStringExtension( " : ", " ( " ) )
	println( names.joinToStringExtension( " : ", " ( ", " ) " ) )

	println( names.joinToStringExtension(" #### ", " [[[ ", " ]]] " ) )
	println( names.joinToStringExtension() )
	println( names.joinToStringExtension(" #### " ) )
	println( names.joinToStringExtension(" #### ", " [[[ " ) )
	println( names.joinToStringExtension(" #### ", " [[[ ", " ]]] " ) )

	val numbers = arrayListOf( 100, 200, 300, 400, 500 ) // ArrayList<Int>
	println( numbers.javaClass )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( numbers.joinToStringExtension( " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( numbers.joinToStringExtension( " #### ", " [[[ ", " ]]] " ) )

    val strings = listOf("first", "second", "fourteenth")
	println( strings.joinToStringExtension( " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( strings.joinToStringExtension( " #### ", " [[[ ", " ]]] " ) )
}

//_____________________________________________________________________

fun Collection<String>.join(
	seperator : String = " , ",
	prefix : String = "",
	postfix : String = ""
) = joinToStringExtension( seperator, prefix, postfix )
// ) : String {

// 	val result = StringBuilder( prefix )

// 	for( (index, element) in this.withIndex() ) {
// 		if ( index > 0 ) result.append( seperator )
// 		result.append( element )
// 	}

// 	result.append( postfix )
// 	return result.toString()
// }

fun playWithJoinExtension() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( names.join() )
	println( names.join( " : " ) )
	println( names.join( " : ", " >>>> " ))
	println( names.join( " # ", " >>> ", " <<< " ))
	println( names.join( " ## ", " [ ", " ] " ))

	// val numbers = listOf(10, 20, 30, 40, 50)
	// println( numbers.join( ))
	// println( numbers.join( " : " ))
	// println( numbers.join( " : ", " >>>> " ))
	// println( numbers.join( " # ", " >>> ", " <<< " ))
	// println( numbers.join( " ## ", " [ ", " ] " ))
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithStringExtenstionFunctions")
	playWithStringExtenstionFunctions()

	println("\nFunction: playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction: playWithJoinToString")
	playWithJoinToString()

	println("\nFunction: playWithJoinToStringWithDefaults")
	playWithJoinToStringWithDefaults()

	println("\nFunction: playWithJoinToStringWithDefaultsAndGenerics")
	playWithJoinToStringWithDefaultsAndGenerics()

	println("\nFunction: playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction: playWithJoinExtension")
	playWithJoinExtension()
	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
