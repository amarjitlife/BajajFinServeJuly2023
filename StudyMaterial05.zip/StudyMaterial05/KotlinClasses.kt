/***
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar 
***/
package learnKotlin

//_____________________________________________________________________

// In Java
//		Clasess Are Open By Default
//			Can Be Inherited From
//		Member Functions Are Also Open By Default
//			Can Be Overridden

// In Kotlin
//		Clasess Are Final By Default
//			Can't Be Inherited From
//		Member Functions Are Also Final By Default
//			Can't Be Overridden
//		override Keyword Required To Override Parent Class Function

open class View {
	open fun click() 	= println("View Clicked!")
}

// Inheritance : Button Inheriting From View Class
class Button : View() {
	override fun click() 	= println("Button Clicked!")
	fun magic() 			= println("Button Magic...")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
	button.magic()

	val viewAgain: View = Button()
	viewAgain.click()
	// error: unresolved reference: magic
	// viewAgain.magic() // Step Motherly Treatment Given To magic Function

	// viewAgain = button
	val letBringKiduBack = viewAgain as Button
	letBringKiduBack.magic()
}

//_____________________________________________________________________
//In Java
	// Employee e = new Employee("Gabbar Singh", 50000 );

// In C/C++
	// Empoloyee *e = ( Employee * ) malloc( sizeof( Employee ) );
	// e -> name 	= "Gabbar Singh";
	// e -> salary  = 50000; 

//_____________________________________________________________________

// Extension Functions
//		doMagic() Is An Extension Function On String Type
fun String.doMagic() {
	println("Adding Magic To String Class...")
}

// Functions Taking String Type Argument and Returing Char Type Value
fun lastCharacter( string: String ) : Char = string.get( string.length  - 1 )

// Extension Functions
//		lastCharacterExt() Is An Extension Function On String Type
//		Returing Char Type Value
fun String.lastCharacterExt() : Char = this.get( this.length  - 1 )

fun playWithStringExtenstionFunctions() {
	val greeting = "Good Evening!"

	greeting.doMagic()

	println( lastCharacter( "Good Evening!" ) )
	println( lastCharacter( "Flat Number #4569" ) )

	println( "Good Evening!".lastCharacterExt() )
	println( "Flat Number #4569".lastCharacterExt() )
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithInheritance")
	playWithInheritance()

	println("\nFunction: playWithStringExtenstionFunctions")
	playWithStringExtenstionFunctions()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
