/***
kotlinc Human.kt -include-runtime -d human.jar
java -jar human.jar 
***/
package learnKotlin

//_____________________________________________________________________

// DESIGN PRINCIPLE
//		DESIGN TOWARDS INTERFACES RATHER THAN CONCRETE CLASSES

// Abstract Type
//		{ Operations, Phi }

// Superpower Is Abstract Type
//		{ {fly, saveWorld }, Phi }
// Behaviour Driven Design
interface Superpower {
	fun fly()
	fun saveWorld()
}

class Spiderman : Superpower {
	override fun fly() 		 { println("Fly Like Spiderman!") 		}
	override fun saveWorld() { println("Save World Like Spiderman!") 	}
}

class Superman : Superpower {
	override fun fly() 		 { println("Fly Like Superman!") 		}
	override fun saveWorld() { println("Save World Like Superman!") 	}
}

class Wonderwoman : Superpower {
	override fun fly() 		 { println("Fly Like Wonderwoman!") 		}
	override fun saveWorld() { println("Save World Like Wonderwoman!") 	}
}

class HanumanJi : Superpower {
	override fun fly() 		 { println("Fly Like HanumanJi!") 		}
	override fun saveWorld() { println("Save World Like HanumanJi!") 	}
}

class Thor : Superpower {
	override fun fly() 		 { println("Fly Like Thor!") 		}
	override fun saveWorld() { println("Save World Like Thor!") 	}
}

open class Heman {
	open fun fly() 		 { println("Fly Like Heman!") 		}
	open fun saveWorld() { println("Save World Like Heman!") 	}
}

//_____________________________________________________________________
// DESIGN 01 : Using Inheritance
// class Human : Spiderman() {
// class Human : Superman() {	
// class Human : Heman() {	
class HumanDesign01 : Heman() {	
	override fun fly() 			{ super.fly() 		}
	override fun saveWorld() 	{ super.saveWorld() }
}

fun playWithHumaDesign01() {
	val h = HumanDesign01()
	h.fly()
	h.saveWorld()
}

//_____________________________________________________________________

// DESIGN 02 : Using Composition
// Human Is Polymorphic In Nature
class Human {	
	// var power: Spiderman = Spiderman()
	// var power: Superman = Superman()
	// var power: Wonderwoman = Wonderwoman()
	// power Is Delegate
	var power : Superpower? = null
	fun fly() 			{ power?.fly() 		} 	//  if (power != null) fly()
	fun saveWorld() 	{ power?.saveWorld() }  //  if (power != null) saveWorld()
}

fun playWithHumaDesign02() {
	val h = Human()
	h.fly()
	h.saveWorld()
	
	// : error: type mismatch: inferred type is Spiderman but Superpower? was expected
	h.power = Spiderman()
	h.fly()
	h.saveWorld()

	h.power = Superman()
	h.fly()
	h.saveWorld()

	h.power = Wonderwoman()
	h.fly()
	h.saveWorld()

	h.power = HanumanJi()
	h.fly()
	h.saveWorld()

	h.power = Thor()
	h.fly()
	h.saveWorld()
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithHumaDesign01")
	playWithHumaDesign01()

	println("\nFunction: playWithHumaDesign02")
	playWithHumaDesign02()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}
/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
