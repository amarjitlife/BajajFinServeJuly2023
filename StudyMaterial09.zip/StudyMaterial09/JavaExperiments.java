/*
// Compilating Java Code 
javac JavaExperiments.java -d ClassFiles

// Running Java Code
java -cp ClassFiles/ learnJava.JavaExperiments
*/
package learnJava;

//_____________________________________________________________________

class Employee {
    public String name;
    public double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

//_____________________________________________________________________

class EmployeeDemo {
    //                            
    public static void doChange( Employee  e ) {
        e = new Employee("Samba", 5000 );

        System.out.println( e.getName());
        System.out.println( e.getSalary());        
    }

    // In Java Objects Are Pass By Reference
    public static void doChangeAgain( Employee e ) {
        // e = new Employee("Samba", 5000 );
        e.name      = "Gabbar Singh Decoit";
        e.salary    = 1000000; 

        System.out.println( e.getName());
        System.out.println( e.getSalary());        
    }

    public static void playWithEmployee() {
        Employee gabbar = new Employee("Gabbar Singh", 50000);

        gabbar.raiseSalary(50000);
        System.out.println( gabbar.getName());
        System.out.println( gabbar.getSalary());
    
        System.out.println("Before Do Change Called...");
        // gabbar Is Reference Of Object
        // Passing gabbar i.e. Passing Reference Of Object
        //  i.e. gabbar reference is Pass By Value
        //  gabbar reference pointing To Object that Object is Pass By Reference.
        doChange( gabbar );
        System.out.println("After Do Change Called...");
        System.out.println( gabbar.getName());
        System.out.println( gabbar.getSalary());        

        doChangeAgain( gabbar );
        System.out.println("After Do Change Again Called...");
        System.out.println( gabbar.getName());
        System.out.println( gabbar.getSalary());        

    }
}

//_____________________________________________________________________

class Nullability {
    public static void playWithNullability() {
        Employee gabbar = new Employee("Gabbar Singh", 50000);
        System.out.println( gabbar.getName());

        gabbar = null;     
        System.out.println( gabbar );
        if ( gabbar != null) {
            System.out.println( gabbar.getName());
        } else {
            System.out.println( "Met with Nothinness...");
        }

        Employee basanti = new Employee("Basanti Only", 5000);
        System.out.println( basanti.getName());

        basanti = null;
        System.out.println( basanti );        
        if ( basanti != null) {
            System.out.println( basanti.getName());
        } else {
            System.out.println( "Met with Nothinness...");
        }

    }
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

class JavaExperiments {
    public static void main( String [] args ) {
        System.out.println("\n\nFunction : playWithEmployee");
        EmployeeDemo.playWithEmployee();

        System.out.println("\n\nFunction : playWithNullability");
        Nullability.playWithNullability();

        // System.out.println("\n\nFunction : ");
        // System.out.println("\n\nFunction : ");
        // System.out.println("\n\nFunction : ");
        // System.out.println("\n\nFunction : ");
    }
}
