_____________________________________________________________________

DAY 01
_____________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions [ MUST ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Java Coding and Experimenation Assignments [ MUST MUST ]
		Practice and Experiment Java Code Till Now Done!!!		
		Calender Program In Java

	Assignment A3 : Thinking and Exploration Assignments 
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics
		A2.4 : What Algorithm Chitargupt Running To Figure Out
				Whoes Time Is Over!
_____________________________________________________________________

DAY 02
_____________________________________________________________________

	Assignment A1 : Java Reading Assignments [ MUST MUST ]
		Reference Book: Java Complete Reference, Latest Edition
			Read The Following Chapters:
				Introducing Classes
				A Closer Look at Methods and Classes
				Inheritance
				Packages and Interfaces
				Exception Handling

	Assignment A2 : Java Coding and Experimenation Assignments [ MUST MUST ]
		Practice and Experiment Java Code Till Now Done!!!		
		Calender Program In Java

_____________________________________________________________________

DAY 03
_____________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]
		Chapter 02: Types, Operators And Expressions 	[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Kotlin Coding and Experimenation Assignments [ MUST MUST ]
		Practice and Experiment Kotlin Code Till Now Done!!!		

_____________________________________________________________________

DAY 04
_____________________________________________________________________

	Assignment K1 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 01: Kotlin: What and Why?
			Chapter 02: Kotlin Basics  				[ THOROUGH READING ]

	Assignment K2 : Kotlin Coding and Experimenation Assignments [ MUST MUST ]
		1. Practice and Experiment Kotlin Code Till Now Done In Class!!!		
		2. KotlinBasicsMore.kt Practice Code and Fix All Warnings!!!
		3. KotlinCollections.kt Practice Code and Fix All Warnings!!!

	Assignment C1 : Reading, Thinking Assignment [ MUST MUST ] [ CHALLENGE MARKS 10/20 ]
		Chapter 05: Pointers and Arrays 				[ THOROUGH READING ]
		Chapter 02: Types, Operators And Expressions 	[ THOROUGH READING ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment J1 : Java Reading Assignments [ MUST MUST ]
		Reference Book: Java Complete Reference, Latest Edition
			Read The Following Chapters:
				Introducing Classes
				A Closer Look at Methods and Classes
				Inheritance
				Packages and Interfaces
				Exception Handling

	Assignment J2 : Java Coding and Experimenation Assignments [ MUST MUST ]
		Practice and Experiment Java Code Till Now Done!!!		
		Calender Program In Java

_____________________________________________________________________

DAY 05
_____________________________________________________________________

	Assignment K1 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]

	Assignment K2 : Kotlin Coding and Experimenation Assignments [ MUST MUST ]
		1. Practice and Experiment Kotlin Code Till Now Done In Class!!!		
		2. KotlinBasicsMore.kt Practice Code and Fix All Warnings!!!
		3. KotlinCollections.kt Practice Code and Fix All Warnings!!!

_____________________________________________________________________

DAY 06
_____________________________________________________________________

	Assignment K1 : Kotlin Reading Assignments [ MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 02: Kotlin Basics  							[ THOROUGH READING ]
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces 		[ THOROUGH READING ]

	Assignment K2 : Kotlin Coding and Experimenation Assignments [ MUST MUST ]
		1. Practice and Experiment Kotlin Code Till Now Done In Class!!!		

_____________________________________________________________________

DAY 07
_____________________________________________________________________

	Assignment K1 : Kotlin Reading Assignments [ MUST MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 03: Kotlin Defining and Calling Functions 	[ THOROUGH READING ]
			Chapter 04: Classes, Objects and Interfaces 		[ THOROUGH READING ]

	Assignment K2 : Kotlin Coding and Experimenation Assignments [ MUST MUST ]
		1. Practice and Experiment Kotlin Code Till Now Done In Class!!!		

	Assignment E1 : Reading Assignments For Exploration [ MUST ]
		Java Varargs
		https://www.baeldung.com/java-varargs
		Kotlin Varargs
		https://www.baeldung.com/kotlin/varargs-spread-operator

	Assignment A1 : Reading Assignments For Advance Learners [ GOOD TO STUDY ]
		Equality and HashCode Contracts
		https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html
		https://www.baeldung.com/java-equals-hashcode-contracts

_____________________________________________________________________

DAY 08
_____________________________________________________________________

	Assignment K1 : Kotlin Reading Assignments [ MUST MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 04: Classes, Objects and Interfaces 		[ THOROUGH READING ]
			Chapter 05: Programming with Lambdas 				[ THOROUGH READING ]
			Chapter 08: Higher Order Functions 					[ THOROUGH READING ]

	Assignment K2 : Kotlin Coding and Experimenation Assignments [ MUST MUST ]
		1. Practice and Experiment Kotlin Code Till Now Done In Class!!!		

_____________________________________________________________________

DAY 09: 
_____________________________________________________________________

	Assignment K1 : Kotlin Reading Assignments [ MUST MUST MUST ]	
		Reference Book: Kotlin In Action By DMITRY JEMEROV AND SVETLANA ISAKOVA
			Chapter 04: Classes, Objects and Interfaces 		[ THOROUGH READING ]
			Chapter 05: Programming with Lambdas 				[ THOROUGH READING ]
			Chapter 06: The Kotlin Type Systems  				[ THOROUGH READING ]
			Chapter 07: Operator Overloading   					[ THOROUGH READING ]
			Chapter 08: Higher Order Functions 					[ THOROUGH READING ]

	Assignment K2 : Kotlin Coding and Experimenation Assignments [ MUST MUST ]
		Practice and Experiment Kotlin Code Till Now Done In Class!!!		

	Assignment K3 : Kotlin Code In Practice Assignments [ MUST MUST ]
		PayrolDesign [ Kotlin Code In Practice ]
			First Two Points 						[ COMPULSORY ]
			Third Points 							[ OPTIONAL ]
			Next 03 Points For Excited Souls! 		[ GOOD TO HAVE... ]
_____________________________________________________________________

DAY 10
_____________________________________________________________________


_____________________________________________________________________

DAY 11
_____________________________________________________________________


_____________________________________________________________________

DAY 12
_____________________________________________________________________


_____________________________________________________________________

DAY 13
_____________________________________________________________________


_____________________________________________________________________

DAY 14
_____________________________________________________________________


_____________________________________________________________________

DAY 15
_____________________________________________________________________


_____________________________________________________________________

FUTURE WORK
_____________________________________________________________________

Reference Book
	Data Structures and Program Design In C/C++ By Kruse

	
