_______________________________________________________

Android Environment 
_______________________________________________________


_______________________________________________________

Kotlin Environment 
_______________________________________________________

1. Kotlin Compiler Download Link
	https://github.com/JetBrains/kotlin/releases

2. Download Kotlin Compiler
	kotlin-compiler-1.8.22.zip

	In Download Directory
	
3. Go To Download Directory
	In Unix/Linux/Mac OSX
		unzip kotlin-compiler-1.8.22.zip
	
	In Windows
		Double Click To Extract

4. You Will Get Following kotlinc Directory

	Download/kotlinc/

	or Use Online Kotlin Compiler/Playground

	https://play.kotlinlang.org/

_______________________________________________________

Write Code
_______________________________________________________

DESIGN 01
Write Following sum Function In C

	int sum(int x, int y) {
		return x + y;
	}

DESIGN 02
Write Following sum Function In C
	It Should Returns Valid Arithmetic Sum Of x And y
	Otherwise Print Can't Calculate Sum For Given x And y

	int sum(int x, int y) {

	}

_______________________________________________________

Contact Details
_______________________________________________________

	Contact Number: +91 9980 777 145
	Email ID : amarjitlife@gmail.com
		Follow Stack Overflow Guidlines
	LinkedIn : www.linkedin.com/in/amarjitlife
_______________________________________________________
_______________________________________________________


