/*
// Compilating Java Code 
javac JavaEquality.java -d ClassFiles

// Running Java Code
java -cp ClassFiles/ learnJava.JavaEquality
*/
package learnJava;

import java.util.Objects;

//_____________________________________________________________________

// class Client2( val name: String, val postalCode: Int ) {
//     override fun toString() : String {
//         return "Client1(name=$name, postalCode=$postalCode)"
//     }

//     override fun equals( other: Any? ) : Boolean {
//         println("Equals Function Getting Called...")
//         if ( other == null || other !is Client2 ) return false
//         return name == other.name && postalCode == other.postalCode
//     }   
// }

class Client2 {
    public String name;
    public int postalCode;

    public Client2(String name, int postalCode ){
        this.name       = name;
        this.postalCode = postalCode;
    }

    @Override 
    public String toString() {
        String output = "Client2(name="+name+"postalCode="+postalCode+")";
        return output;
    }

    @Override
    public boolean equals( Object other ) {
        System.out.println("equals Method Got Called...");
        if ( this == other ) return true;

        if ( other == null ) return false;
        if ( getClass() != other.getClass() ) return false;
    
        Client2 otherObject = ( Client2 ) other;

        return Objects.equals( name, otherObject.name ) && 
             Objects.equals( postalCode, otherObject.postalCode); 
    }
}

class Client2Demo {
    public static void playWithClient2() {
        Client2 veeru = new Client2("Veeru", 999888 );

        System.out.println( "Name: " + veeru.name );
        System.out.println( "Code: " + veeru.postalCode);

    //  Compiler Will Convert Following Line Of Code To println( veeru.toString() )
        System.out.println( veeru );    // println( veeru.toString() )

        Client2 veeruDuplicate = new Client2("Veeru", 999888 );
        System.out.println( "Checking Same To Same Or Not...");
        //  Compiler Will NOT Convert Following Line Of Code To 
        //         System.out.println( veeru.equals( veeruDuplicate ) )
        System.out.println( veeru == veeruDuplicate ); 

        // NOTE:: Programmer Have To Explicitly Call equals Method
        //          To Check Equality
        System.out.println( veeru.equals(veeruDuplicate) ); 

        Client2 reference1 = veeru;
        System.out.println( veeru == reference1 );      // println( veeru.equals( reference1 ) )        
    }
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

public class JavaEquality {

	public static void main( String [] args ) {
        System.out.println("\nFunction : playWithClient2");
        Client2Demo.playWithClient2();

        // System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/

