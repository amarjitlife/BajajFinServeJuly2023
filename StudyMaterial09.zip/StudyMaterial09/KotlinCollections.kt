/***
kotlinc KotlinCollections.kt -include-runtime -d collections.jar
java -jar collections.jar 
***/

package learnKotlin

import kotlin.math.*
import java.util.HashMap

//_____________________________________________________________________

fun playWithFunctionsInKotlin() {

    // FUNCTION BASICS
    fun printMyName() {
        println("My name is Joe Howard.")
    }
    printMyName()

    // FUNCTION PARAMETERS
    fun printMultipleOfFive(value: Int) {
        println("$value * 5 = ${value * 5}")
    }
    printMultipleOfFive(10)

    fun printMultipleOf(multiplier: Int, andValue: Int) {
        println("$multiplier * $andValue = ${multiplier * andValue}")
    }
    printMultipleOf(multiplier = 4, andValue = 2)

    fun printMultipleOfDefaultValue(multiplier: Int, value: Int = 1) {
        println("$multiplier * $value = ${multiplier * value}")
    }
    printMultipleOfDefaultValue(4, 2)

    printMultipleOfDefaultValue(4)

    // RETURN VALUES
    fun multiply(number: Int, multiplier: Int): Int {
        return number * multiplier
    }

    fun multiplyInferred(number: Int, multiplier: Int) = number * multiplier

    val result = multiplyInferred(4, 2)

    fun multiplyAndDivide(number: Int, factor: Int): Pair<Int, Int> {
        return Pair(number * factor, number / factor)
    }
    val (product, quotient) = multiplyAndDivide(4, 2)

//  Parameters as values
//  fun incrementAndPrint(value: Int) {
//    value += 1 // Val cannot be reassigned
//    print(value)
//  }

    fun incrementAndPrint(value: Int): Int {
        val newValue = value + 1
        println(newValue)
        return newValue
    }

    var value = 5
    value = incrementAndPrint(value)
    println(value)

    // OVERLOADING
    fun getValue(value: Int): Int {
        return value + 1
    }

    fun getValue(value: String): String {
        return "The value is $value"
    }

    val valueInt: Int = getValue(42)
    val valueString: String = getValue("Galloway")

    // FUNCTIONS AS VARIABLES
    fun add(a: Int, b: Int): Int {
        return a + b
    }

    var function = ::add
    function(4, 2)

    fun subtract(a: Int, b: Int): Int {
        return a - b
    }
    function = ::subtract
    function(4, 2)

    fun printResult(function: (Int, Int) -> Int, a: Int, b: Int) {
        val result = function(a, b)
        print(result)
    }
    printResult(::add, 4, 2)

    // LAND OF NO RETURN
    // fun noReturn() : Nothing {
    //
    // }

    fun infiniteLoop(): Nothing {
        while (true) {
        }
    }
}

//_____________________________________________________________________


fun playWithArraysInKotlin() {

    // Creating arrays

    val evenNumbers = arrayOf(2, 4, 6, 8)

    val fiveFives = Array(5, { 5 })
    println(fiveFives.joinToString())

    val vowels = arrayOf("a", "e", "i", "o", "u")

    // // Arrays of primitive types

    val oddNumbers = intArrayOf(1, 3, 5, 7)

    val otherOddNumbers = arrayOf(1, 3, 5, 7).toIntArray()

    val zeros = DoubleArray(4)
    println(zeros.joinToString())

    // Creating lists

    val innerPlanets = listOf("Mercury", "Venus", "Earth", "Mars")

    val innerPlanetsArrayList: ArrayList<String> = arrayListOf("Mercury", "Venus", "Earth", "Mars")

    val subscribers: List<String> = listOf()

    // Mutable lists

    val outerPlanets = mutableListOf("Jupiter", "Saturn", "Uranus", "Neptune")

    val exoPlanets = mutableListOf<String>()

    // Accessing elements

    // // Using properties and methods

    val players = mutableListOf("Alice", "Bob", "Cindy", "Dan")
    println(players.isEmpty()) // > false

    if (players.size < 2) {
        println("We need at least two players!")
    } else {
        println("Let's start!")
    }
    // > Let's start!

    val arr = arrayOf<Int>()
//  println(arr.first()) // NoSuchElementException

    var currentPlayer = players.first()
    println(currentPlayer) // > Alice

    println(players.last()) // > Dan

    val minPlayer = players.min()
    minPlayer.let {
        println("$minPlayer will start") // > Alice will start
    }

    println(arrayOf(2, 3, 1).first())
    // > 2
    println(arrayOf(2, 3, 1).min())
    // > 1

    val maxPlayer = players.max()
    if (maxPlayer != null) {
        println("$maxPlayer is the MAX") // > Dan is the MAX
    }

    // // Using indexing

    val firstPlayer = players[0]
    println("First player is $firstPlayer")
    // > First player is Alice

    val secondPlayer = players.get(1)

    // val player = players[4] // > IndexOutOfBoundsException

    // // Using ranges to slice

    val upcomingPlayersSlice = players.slice(1..2).toMutableList()
    println(upcomingPlayersSlice.joinToString()) // > Bob, Cindy

    val upcomingPlayersArray = players.slice(1..2).toTypedArray()
    println(upcomingPlayersArray.joinToString()) // > Bob, Cindy

    // // Checking for an element

    fun isEliminated(player: String): Boolean {
        return player !in players
    }

    println(isEliminated("Bob")) // > false

    players.slice(1..3).contains("Alice") // false

    // Modifying lists

    // // Adding elements

    players.add("Eli")
    println(players.joinToString()) // > "Alice", "Bob", "Cindy", "Dan", "Eli"

    players += "Gina"
    println(players.joinToString()) // > "Alice", "Bob", "Cindy", "Dan", "Eli", "Gina"

    players.add(5, "Frank")
    println(players.joinToString()) // > "Alice", "Bob", "Cindy", "Dan", "Eli", "Frank", "Gina"

    var array = arrayOf(1, 2, 3)
    array += 4
    println(array.joinToString()) // > 1, 2, 3, 4

    // // Removing elements

    val wasPlayerRemoved = players.remove("Gina")
    println("It is $wasPlayerRemoved that Gina was removed") // > It is true that Gina was removed

    val removedPlayer = players.removeAt(2)
    println("$removedPlayer was removed") // > Cindy was removed

    // // Updating elements

    println(players.joinToString()) // > "Alice", "Bob", "Dan", "Eli", "Frank"
    players[4] = "Franklin"
    println(players.joinToString()) // > "Alice", "Bob", "Dan", "Eli", "Franklin"

    players[3] = "Anna"
    players.sort()
    println(players.joinToString()) // > "Alice", "Anna", Bob", "Dan", "Franklin"

    val arrayOfInts = arrayOf(1, 2, 3)
    arrayOfInts[0] = 4
    println(arrayOfInts.joinToString()) // > 4, 2, 3

    // Iterating through a list

    val scores = listOf(2, 2, 8, 6, 1)

    for (player in players) {
        println(player)
    }
    // > Alice
    // > Anna
    // > Bob
    // > Dan
    // > Franklin

    for ((index, player) in players.withIndex()) {
        println("${index + 1}. $player")
    }
    // > 1. Alice
    // > 2. Anna
    // > 3. Bob
    // > 4. Dan
    // > 5. Franklin

    fun sumOfElements(list: List<Int>): Int {
        var sum = 0
        for (number in list) {
            sum += number
        }
        return sum
    }

    println(sumOfElements(scores)) // > 19
}

//_____________________________________________________________________

// import java.util.HashMap

fun playWithMapsAndSetsInKotlin() {

  /*
   * Maps
   */

    // Creating maps

    var yearOfBirth = mapOf("Anna" to 1990, "Brian" to 1991, "Craig" to 1992, "Donna" to 1993)

    var namesAndScores = mutableMapOf("Anna" to 2, "Brian" to 2, "Craig" to 8, "Donna" to 6)
    println(namesAndScores) // > {Anna=2, Brian=2, Craig=8, Donna=6}

    namesAndScores = mutableMapOf()

    var pairs = HashMap<String, Int>()

    pairs = HashMap<String, Int>(20)

    // Accessing values

    // // Using the index operator

    namesAndScores = mutableMapOf("Anna" to 2, "Brian" to 2, "Craig" to 8, "Donna" to 6)
    // Restore the values

    println(namesAndScores["Anna"])
    // > 2

    val gregScore = namesAndScores["Greg"]
    println(gregScore) // > null

    // // Using properties and methods

    println(namesAndScores.get("Craig"))
    // > 8

    namesAndScores.isEmpty() // false
    namesAndScores.size // 4

    // Modifying mutable maps

    // // Adding pairs

    val bobData = mutableMapOf("name" to "Bob", "profession" to "CardPlayer", "country" to "USA")
    bobData.put("state", "CA")
    bobData["city"] = "San Francisco"

    // // Updating values

    bobData.put("name", "Bobby") // Bob

    bobData["profession"] = "Mailman"

    val pair = "nickname" to "Bobby D"
    bobData += pair

    println(bobData)
    // > {name=Bobby, profession=Mailman, country=USA, state=CA, city=San Francisco, nickname=Bobby D}

    // // Removing pairs

    bobData.remove("city")
    bobData.remove("state", "CA")

    println(bobData)
    // > {name=Bobby, profession=Mailman, country=USA, nickname=Bobby D}

    // Iterating through maps

    for ((player, score) in namesAndScores) {
        println("$player - $score")
    }
    // > Anna - 2
    // > Brian - 2
    // > Craig - 8
    // > Donna - 6

    for (player in namesAndScores.keys) {
        print("$player, ") // no newline
    }
    println() // print a newline
    // > Anna, Brian, Craig, Donna,

    // Running time for map operations

    class Bob
    val bob = Bob()

    val mapp = hashMapOf(bob to 2)

    println("some string".hashCode())
    // > 1395333309

    println(1.hashCode())
    // > 1
    println(false.hashCode())
    // > 1237

  /*
   * Sets
   */

    // Creating sets

    val names = setOf("Anna", "Brian", "Craig", "Anna")
    println(names)
    // > [Anna, Brian, Craig]

    val hashSet = HashSet<Int>()

    val someArray = arrayOf(1, 2, 3, 1)

    var someSet = mutableSetOf(*someArray)
    println(someSet) // > [1, 2, 3]

    // Accessing elements

    println(someSet.contains(1))
    // > true

    println(4 in someSet)
    // > false

    println(someSet.first())
    println(someSet.last())

    // Adding and removing elements

    someSet.add(5)

    val removedOne = someSet.remove(1)
    println(removedOne) // > true

    println(someSet)
    // > [2, 3, 5]
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
   println("\n\nFunction: playWithFunctionsInKotlin")
   playWithFunctionsInKotlin()

   println("\n\nFunction: playWithArraysInKotlin")
   playWithArraysInKotlin()

   println("\n\nFunction: playWithMapsAndSetsInKotlin")
   playWithMapsAndSetsInKotlin()
   
   // println("\n\nFunction: ")
   // println("\n\nFunction: ")
   // println("\n\nFunction: ")
   // println("\n\nFunction: ")
   // println("\n\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
