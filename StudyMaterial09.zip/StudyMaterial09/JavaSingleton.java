/*
// Compilating Java Code 
javac JavaSingleton.java -d ClassFiles

// Running Java Code
java -cp ClassFiles/ learnJava.JavaSingleton
*/
package learnJava;


//_____________________________________________________________________

// Singleton Class
//		Class Having Only Instance

class India {
	String name = "Bharatvarsha";

	// Make One private static Member Variable To Store Single Instance
	private static India instance = null ;
	
	// Make Constructor Private
	private India() {} ;
	
	// Make One public static Function To Access Single Instance
	public static India getInstance() {
		if ( instance == null ) {
			instance = new India();
		}
		return instance;
	}
}

class IndiaDemo {
	public static void playWithIndia() {
		// India myIndia 	= new India();
		// India yourIndia 	= new India();
		// India someoneIndia 	= new India();

		// myIndia.name = "My Country";
		// yourIndia.name = "India";
		// someoneIndia.name = "Desh";

		// System.out.println( myIndia.name );
		// System.out.println( yourIndia.name );
		// System.out.println( someoneIndia.name );

		India nation = India.getInstance();
		System.out.println( nation.name );
		System.out.println( nation.name );
	}
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

public class JavaSingleton {

	public static void main( String [] args ) {
        System.out.println("\nFunction : playWithIndia");
        IndiaDemo.playWithIndia();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");				
	}
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/

