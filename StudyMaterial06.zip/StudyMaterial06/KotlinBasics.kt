/***
kotlinc KotlinBasics.kt -include-runtime -d basics.jar
java -jar basics.jar 
***/
package learnKotlin

import java.util.TreeMap

//_____________________________________________________________________

// Function Doesn't Takes Any Argument
fun helloWorld() {
	println("Hello World!");
}

//_____________________________________________________________________
// Function Having
// 		Two Arguments of Type Int and Return Type Int
	
fun max(a: Int, b: Int) : Int {
	// if-else Construct
	// In C/C++/Java
	//		if-else Construct Is A Statement
	//	In Kotlin
	//		if-else Construct Is An Expression
	//		Expression Is A Statement With Return Value

	return if ( a > b ) a else b 
}

fun maximum(a: Int, b: Int) = if ( a > b ) a else b 

fun playWithMaxFunction() {
	println( max( 100, 200 ))
	println( max( 100, -200 ))

	println( maximum( 100, 200 ))
	println( maximum( 100, -200 ))
}

//_____________________________________________________________________

// SYSTEM DESIGN PRINCIPLE
//		DESIGN TOWARDS TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

// Kotlin Compiler Will Generate Following Things
// For The Person Class
//		1. Two Member Variable Correspoding To Each Member Property
//				i.e. name And isMarried Properties
//		2. For Immutable Property Getter Will Be Generated
//				i.e. val Property -> name Property 
//		3. For Mutable Property Getter and Setter Will Be Generated
//				i.e. var Property 
//		4. Will Generated Memberwise Initiliser
//				i.e. Constructor To Initialise All The Member Properties

class Person( val name : String, var isMarried: Boolean )

fun playWithPerson() {
				// Constructor Call
	var gabbar = Person("Gabbar Singh", false)
	println( gabbar.name )
	println( gabbar.isMarried )
	// name Is A Immutable Property
	// Compilation error: val cannot be reassigned
	// gabbar.name = "Gabbar Singh Sober"
	// isMarried Is A Mmutable Property	
	gabbar.isMarried = true
	println( gabbar.name )
	println( gabbar.isMarried )

	var basanti = Person("Basanti", false)
	println( basanti.name )       // basanti.getName()
	println( basanti.isMarried )  // basanti.getIsMarried()

	basanti.isMarried = true 	  // basanti.setIsMarried( true )

	println( basanti.name )       // basanti.getName()
	println( basanti.isMarried )  // basanti.getIsMarried() 	
}

//_____________________________________________________________________

// Creating Rectanle Class Three Immutable Properties
//		viz. width, height and isSquare
//		heigh And width Are Called Stored Properties
//		isSquare Is Computed Property
class Rectangle(val height: Int, val width: Int) {
	val isSquare: Boolean
		// Custom Getter Define By Programmer
		// Hence Compiler Will Not Generate Getter
		get() { 
			return height == width
		}
}

fun playWithRectangle() {
	val rectanlge1 = Rectangle(200, 400)
	println( rectanlge1.width )
	println( rectanlge1.height )
	println( rectanlge1.isSquare )

	val rectanlge2 = Rectangle(400, 400)
	println( rectanlge2.width ) 	// rectangle2.getWidth()	
	println( rectanlge2.height )  	// rectangle2.getHeight()
	println( rectanlge2.isSquare ) 	// rectangle2.getIsSquare()
}

//_____________________________________________________________________

fun playWithTypeInferreingAndBinding() {
	// 1. Type Inferring From RHS
	// 2. Type Binding To LHS
	//		Inferred Type Is Binded To LHS
	
	//In  Kotlin, Java, C, C++ 
	//		Statically Typed Langauge
	//		Type Is Compile Time Decision
	//			Type Inferrencing and Type Binding
	// In Python
	//		Type Is Runtime Decision

	val something = 10
	println( something )

	// Annotating With Explicit Int Type
	val somethingAgain: Int = 10
	println( somethingAgain )

	// error: this variable must either have a type annotation or be initialized
	// val something1

	// val something1 : Int
	// error: variable 'something1' must be initialized
	// println( something1 )	

	val someValue = 90.99 // Default Type Is Double
	println( someValue )

	val someValueAgain: Double = 90.99
	println( someValueAgain )

	val someValue1 = 90.99F // Default Type Is Double
	println( someValue1 )

	val someValueAgain1: Float = 90.99F
	println( someValueAgain1 )

	val greeting = "Good Evening!"
	val greetingAgain : String = "Good Evening!"
	println( greeting )
	println( greetingAgain )
}

//_____________________________________________________________________

enum class Colour {
	RED, GREEN, BLUE, PINK, YELLOW
}

// Compilation Error
// error: 'when' expression must be exhaustive, 
// add necessary 'PINK' branch or 'else' branch instead

// error: type mismatch: inferred type is String but Unit was expected
// fun getColourToString( colour: Colour ) {
fun getColourToString( colour: Colour ) : String {
	return when( colour ) {
		Colour.RED 		-> "RED COLOUR"
		Colour.GREEN 	-> "GREEN COLOUR"
		Colour.BLUE 	-> "BLUE COLOUR"
		// else  			-> "What Color..."
		Colour.PINK 	-> "PINK COLOUR"
		Colour.YELLOW 	-> "YELLOW COLOUR"
		// error: type mismatch: inferred type is IntegerLiteralType
		// [Int,Long,Byte,Short] but Unit was expected
		// Colour.YELLOW 	-> 10
	}
}

// fun getColourToStringAgain( colour: Colour ) : Any = when( colour ) {
fun getColourToStringAgain( colour: Colour ) = when( colour ) {
	Colour.RED 		-> "RED COLOUR"
	Colour.GREEN 	-> "GREEN COLOUR"
	Colour.BLUE 	-> "BLUE COLOUR"
	Colour.PINK 	-> 	10 //"PINK COLOUR"
	else  			-> "What Color..."
	// Colour.PINK 	-> 	10 //"PINK COLOUR"
}

fun playWithColour() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )		
	println( getColourToString( Colour.RED ) )
	println( getColourToString( Colour.GREEN ) )
	println( getColourToString( Colour.BLUE ) )
	println( getColourToString( Colour.PINK ) )

	println( getColourToStringAgain( Colour.RED ) )
	println( getColourToStringAgain( Colour.GREEN ) )
	println( getColourToStringAgain( Colour.PINK ) )
}

//_____________________________________________________________________

fun playWithKotlinIdentifiers() {
	// What Is Type something Type?
	val something = 10
	println( something )

	// error: val cannot be reassigned
	// something = 100
	println( something )	
}

//_____________________________________________________________________

interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right : Expr ) : Expr
class Sub( val left: Expr, val right : Expr ) : Expr
class Mul( val left: Expr, val right : Expr ) : Expr
class Div( val left: Expr, val right : Expr ) : Expr

fun eval( expr : Expr ) : Int {
	// What Is Type Of expr Here?
	//		Expr 
	// 	Checking Type Of expr Is Num?
	if ( expr is Num ) { // Smart Type Casting
		// If expr is Num True Cast To Num Type
		// What Is Type Of expr Here?
		//		Num Type
		return expr.value
	}
	// What Is Type Of expr Here?
	//		Expr
	if ( expr is Sum ) {
		// If expr is Sum True Cast To Sum Type
		// What Is Type Of expr Here?
		//		Sum Type
		return eval( expr.left ) + eval( expr.right )
	}

	throw IllegalArgumentException("Unknown Expression!!!")
}

fun playWithEval() {
	// 100 + 200
	var result: Int
	result= eval( Sum( Num( 100 ), Num( 200 ) ) )
	println("Result : $result")

	// ( 100 + 200 ) + 1000
	result = eval( Sum( Sum( Num(100), Num(200) ) , Num( 1000 ) ) ) 
	println("Result : $result")
}

//_____________________________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right : Expr ) : Expr

fun evalIf( expr : Expr ) : Int {
	return if ( expr is Num ) { // Smart Type Casting
		expr.value
	} else if ( expr is Sum ) {
		evalIf( expr.left ) + evalIf( expr.right )
	} else {
		throw IllegalArgumentException("Unknown Expression!!!")
	}
}

fun playWithEvalIf() {
	// 100 + 200
	var result: Int
	result= evalIf( Sum( Num( 100 ), Num( 200 ) ) )
	println("Result : $result")

	// ( 100 + 200 ) + 1000
	result = evalIf( Sum( Sum( Num(100), Num(200) ) , Num( 1000 ) ) ) 
	println("Result : $result")
}

//_____________________________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right : Expr ) : Expr

fun evalIfAgain( expr : Expr ) : Int = if ( expr is Num ) {
		expr.value
	} else if ( expr is Sum ) {
		evalIfAgain( expr.left ) + evalIfAgain( expr.right )
	} else {
		throw IllegalArgumentException("Unknown Expression!!!")
}

fun playWithEvalIfAgain() {
	// 100 + 200
	var result: Int
	result= evalIfAgain( Sum( Num( 100 ), Num( 200 ) ) )
	println("Result : $result")

	// ( 100 + 200 ) + 1000
	result = evalIfAgain( Sum( Sum( Num(100), Num(200) ) , Num( 1000 ) ) ) 
	println("Result : $result")
}

//_____________________________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right : Expr ) : Expr

// error: type checking has run into a recursive problem. 
// Easiest workaround: specify types of your declarations explicitly
// fun evalulate( expr : Expr ) = when ( expr) {
fun evalulate( expr : Expr ) : Int = when ( expr) {
	is Num  -> expr.value
	is Sum 	-> evalulate( expr.left ) + evalulate( expr.right )
	else 	-> throw IllegalArgumentException("Unknown Expression!!!")
}

fun playWithEvaluate() {
	// 100 + 200
	var result: Int
	result= evalulate( Sum( Num( 100 ), Num( 200 ) ) )
	println("Result : $result")

	// ( 100 + 200 ) + 1000
	result = evalulate( Sum( Sum( Num(100), Num(200) ) , Num( 1000 ) ) ) 
	println("Result : $result")
}

//_____________________________________________________________________

// Pattern Matching
fun fizzBuzz(i: Int) = when {
    i % 15 == 0 -> "FizzBuzz "
    i % 3 == 0 	-> "Fizz "
    i % 5 == 0 	-> "Buzz "
    else -> "$i "
}

fun playWithFizzBuzz() {
    for (i in 1..100) { // [1, 100] Closed Interval
        print(fizzBuzz(i))
    }

    for (i in 100 downTo 1 step 2) {
        print(fizzBuzz(i))
    }
}

//_____________________________________________________________________

// import java.util.TreeMap
fun iteratingOverMaps() {
	val binaryRepresentation = TreeMap<Char, String>()

	for ( character in 'A'..'F' ) {
		val binary = Integer.toBinaryString( character.code )
		binaryRepresentation[ character ] = binary
	}

	for ( ( letter, binary ) in binaryRepresentation ) {
		println("	$letter = $binary")
	}
}

//_____________________________________________________________________

fun isLetter(character: Char) 	= character in 'a'..'z' || character in 'A'..'Z'
fun isNotDigit(character: Char) = character !in '0'..'9'
fun usingInCheck() {
    println(isLetter('q'))
    println(isNotDigit('x'))
}
fun recognize(character: Char) = when (character) {
    in '0'..'9' 				-> "It's a digit!"
    in 'a'..'z', in 'A'..'Z' 	-> "It's a letter!"
    else 						-> "I don't know..."
}
fun usingInCheckWithWhen() {
    println(recognize('8'))
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: helloWorld")
	helloWorld()	

	println("\nFunction: playWithMaxFunction")
	playWithMaxFunction()

	println("\nFunction: playWithPerson")
	playWithPerson()

	println("\nFunction: playWithRectangle")
	playWithRectangle()

	println("\nFunction: playWithColour")
	playWithColour()

	println("\nFunction: playWithKotlinIdentifiers")
	playWithKotlinIdentifiers()

	println("\nFunction: playWithEval")
	playWithEval()

	println("\nFunction: playWithEvalIf")
	playWithEvalIf()

	println("\nFunction: playWithEvalIfAgain")
	playWithEvalIfAgain()

	println("\nFunction: playWithEvaluate")
	playWithEvaluate()

	println("\nFunction: iteratingOverMaps")
	iteratingOverMaps()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
