/***
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar 
***/
package learnKotlin


//_____________________________________________________________________
//In Java
	// Employee e = new Employee("Gabbar Singh", 50000 );

// In C/C++
	// Empoloyee *e = ( Employee * ) malloc( sizeof( Employee ) );
	// e -> name 	= "Gabbar Singh";
	// e -> salary  = 50000; 

//_____________________________________________________________________

// Adding Functionality To Existing Classes
//		Mechanism Using Extension Function

// Extension Functions
//		doMagic() Is An Extension Function On String Type
fun String.doMagic() {
	println("Adding Magic To String Class...")
}

// Functions Taking String Type Argument and Returing Char Type Value
fun lastCharacter( string: String ) : Char = string.get( string.length  - 1 )

// Extension Functions
//		lastCharacterExt() Is An Extension Function On String Type
//			Returing Char Type Value
fun String.lastCharacterExtension() : Char = this.get( this.length  - 1 )

fun playWithStringExtenstionFunctions() {
	val greeting = "Good Evening!"

	greeting.doMagic()

	println( lastCharacter( "Good Evening!" ) )
	println( lastCharacter( "Flat Number #4569" ) )

	println( "Good Evening!".lastCharacterExtension() )
	println( "Flat Number #4569".lastCharacterExtension() )
}

//_____________________________________________________________________

fun playWithKotlinCollections() {
	val set = hashSetOf(1, 7, 53) 
	val list = arrayListOf(1, 7, 53) 
	val map = hashMapOf(1 to "one", 7 to "seven", 53 to "fifty-three")

    println(set.javaClass)
    println(list.javaClass)
    println(map.javaClass)

    val strings = listOf("first", "second", "fourteenth")
    println(strings.javaClass)
    println(strings.last())
    
    val numbers = setOf(1, 14, 2)
    println(numbers.javaClass)
    //println(numbers.max())
    println(numbers.maxOrNull())
}
// Function: playWithKotlinCollections
// class java.util.HashSet
// class java.util.ArrayList
// class java.util.HashMap
// class java.util.Arrays$ArrayList
// fourteenth
// class java.util.LinkedHashSet
// 14

//_____________________________________________________________________

fun joinToString(
	collection : ArrayList<String>,
	seperator : String,
	prefix : String,
	postfix : String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" )
	println( joinToString( names, " : ", " ( ", " ) " ) )
	println( joinToString( names, " #### ", " [[[ ", " ]]] " ) )

	// val numbers = arrayListOf( 100, 200, 300, 400, 500 )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	// println( joinToString( numbers, " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	// println( joinToString( numbers, " #### ", " [[[ ", " ]]] " ) )
}

//_____________________________________________________________________

fun joinToStringWithDefault(
	collection : ArrayList<String>,
	seperator : String = " ",
	prefix : String = "",
	postfix : String = ""
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringWithDefaults() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" )
	println( joinToStringWithDefault( names, " : ", " ( ", " ) " ) )
	println( joinToStringWithDefault( names ) )
	println( joinToStringWithDefault( names, " : " ) )
	println( joinToStringWithDefault( names, " : ", " ( " ) )
	println( joinToStringWithDefault( names, " : ", " ( ", " ) " ) )

	println( joinToStringWithDefault( names, " #### ", " [[[ ", " ]]] " ) )
	println( joinToStringWithDefault( names ) )
	println( joinToStringWithDefault( names, " #### " ) )
	println( joinToStringWithDefault( names, " #### ", " [[[ " ) )
	println( joinToStringWithDefault( names, " #### ", " [[[ ", " ]]] " ) )

	// val numbers = arrayListOf( 100, 200, 300, 400, 500 )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	// println( joinToString( numbers, " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	// println( joinToString( numbers, " #### ", " [[[ ", " ]]] " ) )
}

//_____________________________________________________________________
// Generics/Template
//		Is A Code Which Will Generate Code

// <E> Is Type Place Holder
//	Compiler Will Substitute Type Place Holder With Type
//		At Compile Time

fun <E> joinToStringWithDefaultAndGenerics(
	collection : Collection<E>,
	seperator : String = " ",
	prefix : String = "",
	postfix : String = ""
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

// Compiler WilL Generate Following Code
//		By Sustituting Type Place Holder
// fun joinToStringWithDefaultAndGenerics(
// 	collection : Collection<String>,
// 	seperator : String = " ",
// 	prefix : String = "",
// 	postfix : String = ""
// ) : String {

// 	val result = StringBuilder( prefix )

// 	for( (index, element) in collection.withIndex() ) {
// 		if ( index > 0 ) result.append( seperator )
// 		result.append( element )
// 	}

// 	result.append( postfix )
// 	return result.toString()
// }

// Compiler WilL Generate Following Code
//		By Sustituting Type Place Holder
// fun joinToStringWithDefaultAndGenerics(
// 	collection : Collection<Int>,
// 	seperator : String = " ",
// 	prefix : String = "",
// 	postfix : String = ""
// ) : String {

// 	val result = StringBuilder( prefix )

// 	for( (index, element) in collection.withIndex() ) {
// 		if ( index > 0 ) result.append( seperator )
// 		result.append( element )
// 	}

// 	result.append( postfix )
// 	return result.toString()
// }

fun playWithJoinToStringWithDefaultsAndGenerics() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" ) // ArrayList<String>
	println( names.javaClass )
	println( joinToStringWithDefaultAndGenerics( names, " : ", " ( ", " ) " ) )
	println( joinToStringWithDefaultAndGenerics( names ) )
	println( joinToStringWithDefaultAndGenerics( names, " : " ) )
	println( joinToStringWithDefaultAndGenerics( names, " : ", " ( " ) )
	println( joinToStringWithDefaultAndGenerics( names, " : ", " ( ", " ) " ) )

	println( joinToStringWithDefaultAndGenerics( names, " #### ", " [[[ ", " ]]] " ) )
	println( joinToStringWithDefaultAndGenerics( names ) )
	println( joinToStringWithDefaultAndGenerics( names, " #### " ) )
	println( joinToStringWithDefaultAndGenerics( names, " #### ", " [[[ " ) )
	println( joinToStringWithDefaultAndGenerics( names, " #### ", " [[[ ", " ]]] " ) )

	val numbers = arrayListOf( 100, 200, 300, 400, 500 ) // ArrayList<Int>
	println( numbers.javaClass )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( joinToStringWithDefaultAndGenerics( numbers, " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( joinToStringWithDefaultAndGenerics( numbers, " #### ", " [[[ ", " ]]] " ) )

    val strings = listOf("first", "second", "fourteenth")
	println( joinToStringWithDefaultAndGenerics( strings, " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( joinToStringWithDefaultAndGenerics( strings, " #### ", " [[[ ", " ]]] " ) )
}

//_____________________________________________________________________
// Extention Function
//		joinToStringExtension() Extension Function On Type Collection<E>

fun <E> Collection<E>.joinToStringExtension(
	// collection : Collection<E>,
	seperator : String = " ",
	prefix : String = "",
	postfix : String = ""
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( seperator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	val names = arrayListOf( "Ting", "Tong", "Ding", "Dong" ) // ArrayList<String>
	println( names.javaClass )
	println( names.joinToStringExtension( " : ", " ( ", " ) " ) )
	println( names.joinToStringExtension( ) )
	println( names.joinToStringExtension( " : " ) )
	println( names.joinToStringExtension( " : ", " ( " ) )
	println( names.joinToStringExtension( " : ", " ( ", " ) " ) )

	println( names.joinToStringExtension(" #### ", " [[[ ", " ]]] " ) )
	println( names.joinToStringExtension() )
	println( names.joinToStringExtension(" #### " ) )
	println( names.joinToStringExtension(" #### ", " [[[ " ) )
	println( names.joinToStringExtension(" #### ", " [[[ ", " ]]] " ) )

	val numbers = arrayListOf( 100, 200, 300, 400, 500 ) // ArrayList<Int>
	println( numbers.javaClass )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( numbers.joinToStringExtension( " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( numbers.joinToStringExtension( " #### ", " [[[ ", " ]]] " ) )

    val strings = listOf("first", "second", "fourteenth")
	println( strings.joinToStringExtension( " : ", " ( ", " ) " ) )
	// error: type mismatch: inferred type is kotlin.collections.ArrayList<Int> 
	println( strings.joinToStringExtension( " #### ", " [[[ ", " ]]] " ) )
}

//_____________________________________________________________________

fun Collection<String>.join(
	seperator : String = " , ",
	prefix : String = "",
	postfix : String = ""
) = joinToStringExtension( seperator, prefix, postfix )
// ) : String {

// 	val result = StringBuilder( prefix )

// 	for( (index, element) in this.withIndex() ) {
// 		if ( index > 0 ) result.append( seperator )
// 		result.append( element )
// 	}

// 	result.append( postfix )
// 	return result.toString()
// }

fun playWithJoinExtension() {
	val names = listOf("Ding", "Dong", "Ting", "Tong")
	println( names.join() )
	println( names.join( " : " ) )
	println( names.join( " : ", " >>>> " ))
	println( names.join( " # ", " >>> ", " <<< " ))
	println( names.join( " ## ", " [ ", " ] " ))

	// val numbers = listOf(10, 20, 30, 40, 50)
	// println( numbers.join( ))
	// println( numbers.join( " : " ))
	// println( numbers.join( " : ", " >>>> " ))
	// println( numbers.join( " # ", " >>> ", " <<< " ))
	// println( numbers.join( " ## ", " [ ", " ] " ))
}

//_____________________________________________________________________

// Extension Property
//		Immutable Property Will Have Only Getter
val String.lastChar : Char
	get() = get( length - 1)

// Extension Property
//		Mutable Property Can Have Both Getter and Setter
var StringBuilder.lastChar : Char
	get() = get( length - 1)
	set( value: Char ) {
		this.setCharAt( length - 1, value )
	}

fun playWithExtensionProperties() {
	println( "Kotlin".lastChar ) 			// "Kotlin".getLastChar()
	println( "Good Morning!".lastChar ) 	// "Good Morning!".getLastChar()	

	var sb = StringBuilder( "How are you?" )
	println( sb.lastChar )  // sb.getLastChar()
	sb.lastChar = '#' 		// sb.setLastChar( '#' )
	println( sb )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun parsePath(path: String) {
    val directory = path.substringBeforeLast("/")
    val fullName = path.substringAfterLast("/")

    val fileName = fullName.substringBeforeLast(".")
    val extension = fullName.substringAfterLast(".")

    println("Dir: $directory, name: $fileName, ext: $extension")
}

fun multilineTriplequotedStrings() {
	val kotlinLogo = """| //
	                   .|//
	                   .|/ \"""

    println(kotlinLogo.trimMargin(".") )
}

fun playWithStringFunctions() {
    parsePath("/Users/yole/kotlin-book/chapter.adoc")
    multilineTriplequotedStrings()
}

//_____________________________________________________________________

// DESIGN PRINCIPLE
//		DESGIN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

class User( val id : Int, val name: String, val address: String)

fun saveUser( user: User ) {
	// Validation Logic
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User : ${user.id} EMPTY NAME")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User : ${user.id} EMPTY ADDRESS")
	}

	// Here Goes Logic To SaveUser In Database....
	saveUserInDatabase(user)
}

fun saveUserInDatabase( user: User ) {
	println("Saving User ${user.id} In Database")
}

fun playWithSaveUserFunction() {
	val gabbar = User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  = User( 120, "Samba", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Thakur's Village" )

	saveUser( gabbar )
	saveUser( samba )
	saveUser( basanti )
}

//_____________________________________________________________________

// class User( val id : Int, val name: String, val address: String)

fun saveUserAgain( user: User ) {
	// Local Function
	//		Function Defined Inside A Function
	fun validate( user: User, value: String, fileName: String ) {
		if (value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User : ${user.id} EMPTY $fileName")	
		}
	}

	// Local Function
	//		Function Defined Inside A Function
	fun saveUserInDatabase( user: User ) {
		println("Saving User ${user.id} In Database")
	}

	// Validation Logic	
	validate( user, user.name, "Name")
	validate( user, user.address, "Address")
	
	// Here Goes Logic To SaveUser In Database....
	saveUserInDatabase(user)
}

fun playWithSaveUserAgainFunction() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Thakur's Village" )

	saveUserAgain( gabbar )
	saveUserAgain( samba )
	saveUserAgain( basanti )
}

//_____________________________________________________________________

fun User.save() {
	// Local Function
	//		Function Defined Inside A Function
	fun validate( value: String, fileName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User : ${this.id} EMPTY $fileName")	
		}
	}
	// Local Function
	//		Function Defined Inside A Function
	fun saveUserInDatabase( user: User ) {
		println("Saving User ${user.id} In Database")
	}
	// Validation Logic	
	validate( this.name, "Name")
	validate( this.address, "Address")	
	// Here Goes Logic To SaveUser In Database....
	saveUserInDatabase( this )
}

fun playWithSave() {
	val gabbar 	= User( 420, "Gabbar Singh", "Ramgarh" )
	val samba  	= User( 120, "Samba", "Ramgarh" )
	val basanti = User( 100, "Basanti", "Thakur's Village" )

	gabbar.save()
	samba.save()
	basanti.save()
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\nFunction: playWithStringExtenstionFunctions")
	playWithStringExtenstionFunctions()

	println("\nFunction: playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction: playWithJoinToString")
	playWithJoinToString()

	println("\nFunction: playWithJoinToStringWithDefaults")
	playWithJoinToStringWithDefaults()

	println("\nFunction: playWithJoinToStringWithDefaultsAndGenerics")
	playWithJoinToStringWithDefaultsAndGenerics()

	println("\nFunction: playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction: playWithJoinExtension")
	playWithJoinExtension()
	
	println("\nFunction: playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction: playWithStringFunctions")
	playWithStringFunctions()

	println("\nFunction: playWithSaveUserFunction")
	playWithSaveUserFunction()

	println("\nFunction: playWithSaveUserAgainFunction")
	playWithSaveUserAgainFunction()

	println("\nFunction: playWithSave")
	playWithSave()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/
