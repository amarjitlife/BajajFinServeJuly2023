_____________________________________________________________________

DAY 01
_____________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions [ MUST ]

		Reference : The C Programming Language, 2nd Edition
			By Brian Kernigham and Dennis Ritchie

	Assignment A2 : Java Coding and Experimenation Assignments [ MUST MUST ]
		Practice and Experiment Java Code Till Now Done!!!		
		Calender Program In Java

	Assignment A3 : Thinking and Exploration Assignments 
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics
		A2.4 : What Algorithm Chitargupt Running To Figure Out
				Whoes Time Is Over!
_____________________________________________________________________

DAY 02
_____________________________________________________________________

	Assignment A1 : Java Reading Assignments [ MUST MUST ]
		Reference Book: Java Complete Reference, Latest Edition
			Read The Following Chapters:
				Introducing Classes
				A Closer Look at Methods and Classes
				Inheritance
				Packages and Interfaces
				Exception Handling

	Assignment A2 : Java Coding and Experimenation Assignments [ MUST MUST ]
		Practice and Experiment Java Code Till Now Done!!!		
		Calender Program In Java

_____________________________________________________________________

DAY 03
_____________________________________________________________________

	Assignment A1 : Reading, Thinking Assignment [ MUST MUST ]
		Chapter 05: Pointers and Arrays [ MUST MUST ]
		Chapter 02: Types, Operators And Expressions [ MUST ]


_____________________________________________________________________

DAY 04
_____________________________________________________________________



_____________________________________________________________________

DAY 05
_____________________________________________________________________



_____________________________________________________________________

DAY 06
_____________________________________________________________________



