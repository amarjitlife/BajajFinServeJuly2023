// Compilating Java Code 
// javac JavaObjectOrientedProgramming.java -d ClassFiles

// Running Java Code
// java -cp ClassFiles/ learnJava.JavaObjectOrientedProgramming

package learnJava;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Random;

// import java.time.LocalDate;
import java.util.ArrayList;

//_____________________________________________________________________

class Cal {
    public static void playWithCalender(String [] args) {
        LocalDate date = LocalDate.now().withDayOfMonth(1);
        int month;
        if (args.length >= 2) {        
            month = Integer.parseInt(args[0]);
            int year = Integer.parseInt(args[1]);
            date = LocalDate.of(year, month, 1);
        } else {
            month = date.getMonthValue();
        }
        
        System.out.println(" Mon Tue Wed Thu Fri Sat Sun");
        DayOfWeek weekday = date.getDayOfWeek();
        int value = weekday.getValue(); // 1 = Monday, ... 7 = Sunday
        for (int i = 1; i < value; i++) 
            System.out.print("    ");
        while (date.getMonthValue() == month) {
            System.out.printf("%4d", date.getDayOfMonth());
            date = date.plusDays(1);
            if (date.getDayOfWeek().getValue() == 1) 
                System.out.println();
        }
        if (date.getDayOfWeek().getValue() != 1) 
           System.out.println();
    }
}

//_____________________________________________________________________

class Employee {
    private String name;
    private double salary;
        
    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
}

class EmployeeDemo {
    public static void playWithEmployee() {
        Employee gabbar = new Employee("Gabbar Singh", 50000);
        gabbar.raiseSalary(50000);
        System.out.println( gabbar.getName());
        System.out.println( gabbar.getSalary());
    }
}

//_____________________________________________________________________
// import java.util.Random;

class EvilManager {
    private Random generator;
    
    public EvilManager() {
        generator = new Random();
    }
    
    public void giveRandomRaise(Employee e) {
        double percentage = 10 * generator.nextDouble();
        e.raiseSalary(percentage);
    }
    
    public void increaseRandomly(double x) {
        double amount = x * 10 * generator.nextDouble();
        x += amount;
    }
    
    public void replaceWithZombie(Employee e) {
        e = new Employee("", 0);
    }
}

class EvilManagerDemo {
    public static void playWithObjects() {
        EvilManager boss = new EvilManager();
        Employee gabbar = new Employee("Gabbar Singh", 50000);
        
        System.out.println("Salary before: " + gabbar.getSalary());            
        boss.giveRandomRaise( gabbar );
        System.out.println("Salary after: " + gabbar.getSalary());

        double sales = 100000;
        System.out.println("Sales before: " + sales);
        boss.increaseRandomly( sales );
        System.out.println("Sales after: " + sales);
        
        System.out.println("Employee before: " + gabbar.getName());            
        boss.replaceWithZombie( gabbar );
        System.out.println("Employee after: " + gabbar.getName());            
    }
}

//_____________________________________________________________________

class Employee1 {
    private String name = "";
    private double salary;
    private final int id;
        
    { // An initialization block : Non Static Members
        Random generator = new Random(); 
        id = 1 + generator.nextInt(1_000_000);
    }
    
    public Employee1(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }
    
    public Employee1(double salary) {
        // name already set to ""
        this.salary = salary;
    }        
    
    public Employee1(String name) {
        // salary automatically set to zero
        this.name = name;
    } 
    
    public Employee1() {
        this("", 0);
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int getId() {
        return id;
    }
}

class Employee1ConstructorsDemo {
    public static void playWithEmployee1() {
        Employee1 james = new Employee1("James Bond", 500000);
            // calls Employee(String, double) constructor
        Employee1 anonymous = new Employee1("", 40000);
            // calls Employee(double) constructor
        Employee1 unpaid = new Employee1("Igor Intern");
        Employee1 e = new Employee1();
            // no-arg constructor
    }
}

//_____________________________________________________________________

class Employee2 {
    // private int lastId = 0;
    private static int lastId = 0;
    private int id;
    private String name = "Uknown";
    private double salary;
        
    // public Employee2() {
    private Employee2() {
        lastId++;
        id = lastId;
    }
    
    public Employee2(String name, double salary) {
        this(); // Calling No-Arguments Constructor i.e. Default Constructor
        this.name = name;
        this.salary = salary;
    }

    public void raiseSalary(double byPercent) {
        double raise = salary * byPercent / 100;
        salary += raise;    
    }
    
    public String getName() {
        return name;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public int getId() {
        return id;
    }

    public static String heyBuddy() {
        return "Nalla Erruken!!!";
    }
}

class Employee2Demo {
    public static void playWithEmployee2() {
        // Employee2 e = new Employee2();
        // System.out.println("Employee Name   :" + e.getName() );
        // System.out.println("Employee Salary :" + e.getSalary() );

        Employee2 gabbar = new Employee2("Gabbar Singh", 500000);        
        System.out.println("Employee ID     :" + gabbar.getId() );
        System.out.println("Employee Name   :" + gabbar.getName() );
        System.out.println("Employee Salary :" + gabbar.getSalary() );

        Employee2 sambha = new Employee2("Sambha", 5000);        
        System.out.println("Employee ID     :" + sambha.getId() );
        System.out.println("Employee Name   :" + sambha.getName() );
        System.out.println("Employee Salary :" + sambha.getSalary() );

        Employee2 kalia = new Employee2("Kalia", 1000);        
        System.out.println("Employee ID     :" + kalia.getId() );
        System.out.println("Employee Name   :" + kalia.getName() );
        System.out.println("Employee Salary :" + kalia.getSalary() );

        System.out.println("Employee Data...");
        String message;
        message = gabbar.heyBuddy();
        System.out.println( message );
        // message = e.heyBuddy();
        // System.out.println( message );        

        //error: non-static method getName() cannot be referenced from a static context
        //        Employee2.getName();
        // Employee2.getName();
        // Employee2.getSalary();
        message = Employee2.heyBuddy();
        System.out.println( message );        
    }
}

//_____________________________________________________________________

// import java.time.LocalDate;
// import java.util.ArrayList;

class CreditCardForm {
    private static final ArrayList<Integer> expirationYear = new ArrayList<>();
    
    // Static Block : Used To Initialse Static Members
    static {
        // Add the next twenty years to the array list
        int year = LocalDate.now().getYear();
        for (int i = year; i <= year + 20; i++) {
            expirationYear.add(i);
        }   
    }
    // ...
}

//_____________________________________________________________________

class Invoice {
    private static class Item { // Item is nested inside Invoice
        String description;
        int quantity;
        double unitPrice;

        double price() { return quantity * unitPrice; }
        public String toString() { 
            return quantity + " x " + description + " @ $" + unitPrice + " each";
        }
    }

    private ArrayList<Item> items = new ArrayList<>();
    
    public void addItem(String description, int quantity, double unitPrice) {
        Item newItem = new Item();
        newItem.description = description;
        newItem.quantity = quantity;
        newItem.unitPrice = unitPrice;
        items.add(newItem);
    }
    
    public void print() {
        double total = 0;
        for (Item item : items) {
            System.out.println(item);
            total += item.price();
        }
        System.out.println(total);
    }
}

class InvoiceDemo {
    public static void playWithInvoices() {
        Invoice invoice = new Invoice();
        invoice.addItem("Blackwell Toaster", 2, 24.95);
        invoice.addItem("ZapXpress Microwave Oven", 1, 49.95);
        invoice.print();
    }
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

public class JavaObjectOrientedProgramming {
	public static void main( String [] args ) {
		System.out.println("\n\nFunction : playWithCalender");
		Cal.playWithCalender(args);

		System.out.println("\n\nFunction : playWithEmployee");
		EmployeeDemo.playWithEmployee();

		System.out.println("\n\nFunction : playWithObjects");
        EvilManagerDemo.playWithObjects();

		System.out.println("\n\nFunction : playWithEmployee1");
        Employee1ConstructorsDemo.playWithEmployee1();

		System.out.println("\n\nFunction : playWithEmployee2");
        Employee2Demo.playWithEmployee2();

        System.out.println("\n\nFunction : playWithInvoices");
        InvoiceDemo.playWithInvoices();

        // System.out.println("\n\nFunction : ");
        // System.out.println("\n\nFunction : ");
        // System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
		// System.out.println("\n\nFunction : ");
	}
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/

