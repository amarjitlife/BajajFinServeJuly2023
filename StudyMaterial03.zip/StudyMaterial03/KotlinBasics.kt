/***
kotlinc KotlinBasics.kt -include-runtime -d basics.jar
java -jar basics.jar 
***/
package learnKotlin

//_____________________________________________________________________

// Function Doesn't Takes Any Argument
fun helloWorld() {
	println("Hello World!");
}

//_____________________________________________________________________
// Function Having
// 		Two Arguments of Type Int and Return Type Int

fun max(a: Int, b: Int) : Int {
	return if ( a > b ) a else b 
}

fun playWithMaxFunction() {
	println( max( 100, 200 ))
	println( max( 100, -200 ))
}

//_____________________________________________________________________

// SYSTEM DESIGN PRINCIPLE
//		DESIGN TOWARDS TOWARDS IMMUTABILITY RATHER THAN MUTABILITY

// Kotlin Compiler Will Generate Following Things
// For The Person Class
//		1. Two Member Variable Correspoding To Each Member Property
//				i.e. name And isMarried Properties
//		2. For Immutable Property Getter Will Be Generated
//				i.e. val Property -> name Property 
//		3. For Mutable Property Getter and Setter Will Be Generated
//				i.e. var Property 
//		4. Will Generated Memberwise Initiliser
//				i.e. Constructor To Initialise All The Member Properties

class Person( val name : String, var isMarried: Boolean )

fun playWithPerson() {
				// Constructor Call
	var gabbar = Person("Gabbar Singh", false)
	println( gabbar.name )
	println( gabbar.isMarried )
	// name Is A Immutable Property
	// Compilation error: val cannot be reassigned
	// gabbar.name = "Gabbar Singh Sober"
	// isMarried Is A Mmutable Property	
	gabbar.isMarried = true
	println( gabbar.name )
	println( gabbar.isMarried )

	var basanti = Person("Basanti", false)
	println( basanti.name )       // basanti.getName()
	println( basanti.isMarried )  // basanti.getIsMarried()

	basanti.isMarried = true 	  // basanti.setIsMarried( true )

	println( basanti.name )       // basanti.getName()
	println( basanti.isMarried )  // basanti.getIsMarried() 	
}

//_____________________________________________________________________

// Creating Rectanle Class Three Immutable Properties
//		viz. width, height and isSquare
//		heigh And width Are Called Stored Properties
//		isSquare Is Computed Property
class Rectangle(val height: Int, val width: Int) {
	val isSquare: Boolean
		// Custom Getter Define By Programmer
		// Hence Compiler Will Not Generate Getter
		get() { 
			return height == width
		}
}

fun playWithRectangle() {
	val rectanlge1 = Rectangle(200, 400)
	println( rectanlge1.width )
	println( rectanlge1.height )
	println( rectanlge1.isSquare )

	val rectanlge2 = Rectangle(400, 400)
	println( rectanlge2.width ) 	// rectangle2.getWidth()	
	println( rectanlge2.height )  	// rectangle2.getHeight()
	println( rectanlge2.isSquare ) 	// rectangle2.getIsSquare()
}

//_____________________________________________________________________

enum class Colour {
	RED, GREEN, BLUE, PINK
}

// Compilation Error
// error: 'when' expression must be exhaustive, 
// add necessary 'PINK' branch or 'else' branch instead
fun getColourToString( colour: Colour ) : String {
	return when( colour ) {
		Colour.RED 		-> "RED COLOUR"
		Colour.GREEN 	-> "GREEN COLOUR"
		Colour.BLUE 	-> "BLUE COLOUR"
		// else  			-> "What Color..."
		Colour.PINK 	-> "PINK COLOUR"
	}
}

fun playWithColour() {
	println( Colour.RED )
	println( Colour.GREEN )
	println( Colour.BLUE )		
	println( getColourToString( Colour.RED ) )
	println( getColourToString( Colour.GREEN ) )
	println( getColourToString( Colour.BLUE ) )
	println( getColourToString( Colour.PINK ) )
}

//_____________________________________________________________________

fun playWithKotlinIdentifiers() {
	// What Is Type something Type?
	val something = 10
	println( something )

	// error: val cannot be reassigned
	// something = 100
	println( something )	
}


//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

fun main() {
	println("\n\nFunction: helloWorld")
	helloWorld()	

	println("\n\nFunction: playWithMaxFunction")
	playWithMaxFunction()

	println("\n\nFunction: playWithPerson")
	playWithPerson()

	println("\n\nFunction: playWithRectangle")
	playWithRectangle()

	println("\n\nFunction: playWithColour")
	playWithColour()

	println("\n\nFunction: playWithKotlinIdentifiers")
	playWithKotlinIdentifiers()

	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
	// println("\n\nFunction: ")
}
