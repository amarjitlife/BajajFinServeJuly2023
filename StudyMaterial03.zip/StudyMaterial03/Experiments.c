#include <stdio.h>
// DESIGN 01
// Write Following sum Function In C
int sum(int x, int y) {
	return x + y;
}

void playWithSum() {
	int result = 0, a, b;

	a = 2147483647;
	b = 10;
	result = sum(a, b);
	printf("\nResult : %d", result);

	a = -2147483648;
	b = -10;
	result = sum(a, b);
	printf("\nResult : %d", result);	
}
// Result : -2147483639
// Result : 214748363

// DESIGN 02
// Write Following sum Function In C
// 	It Should Returns Valid Arithmetic Sum Of x And y
// 	Otherwise Print Can't Calculate Sum For Given x And y

// 	int sum(int x, int y) {

// 	}

int main() {
	playWithSum();
}

