// Compilating Java Code 
// javac JavaFundamentals.java -d ClassFiles

// Running Java Code
// java -cp ClassFiles/ learnJava.JavaFundamentals

package learnJava;

import java.util.Random;
import java.time.ZoneId;
import java.util.Scanner;

import java.util.Arrays;
import java.util.ArrayList;


class NumberDemo {
	public static void playWithNumbers() {
        System.out.println(4000000000L); // long literal
        System.out.println(0xCAFEBABE); // hex literal
        System.out.println(0b1001); // binary literal
        System.out.println(011); // octal literal
        
        // Underscores in literals   
        System.out.println(1_000_000_000); 
        System.out.println(0b1111_0100_0010_0100_0000);
        
        // Advanced topic: Unsigned quantities
        System.out.println(Byte.toUnsignedInt((byte )-127));
        
        System.out.println(3.14F); // float literal
        System.out.println(3.14); // double literal
        System.out.println(3.14D); // double literal

        System.out.println(1.0 / 0.0); 
        System.out.println(-1.0 / 0.0);
        System.out.println(0.0 / 0.0);

        System.out.println(1.0 / 0.0 == Double.POSITIVE_INFINITY);
        System.out.println(-1.0 / 0.0 == Double.NEGATIVE_INFINITY);
        System.out.println(0.0 / 0.0 == Double.NaN);  
        
		System.out.println(Double.isInfinite(1.0 / 0.0));
        System.out.println(Double.isInfinite(-1.0 / 0.0));
        System.out.println(Double.isNaN(0.0 / 0.0));      

        System.out.println(Double.isFinite(0.0 / 0.0));
	
        System.out.println(2.0 - 1.1 == 0.9);
	
        System.out.println('J'); 
        System.out.println('J' == 74); 
        System.out.println('\u004A'); 
        System.out.println('\u263A'); 
	
        System.out.println("नमस्ते"); 
	}
}

//_____________________________________________________________________

class VariableDemo {
    public static final int DAYS_PER_YEAR = 365;
    
    enum Weekday { MON, TUE, WED, THU, FRI, SAT, SUN };
    
    public static void playWithVariables() {
        int total = 0;
        int i = 0, count;
        Random generator = new Random();
        double lotsa$ = 1000000000.0; // Legal, but not a good idea
        double élévation = 0.0;
        double π = 3.141592653589793;
        String Count = "Dracula"; // Not the same as count
        int countOfInvalidInputs = 0; // Example of camelCase
        final int DAYS_PER_WEEK = 7;
        Weekday startDay = Weekday.MON;
        // The following line would cause an error since count has not been initialized
        // System.out.println(count); 
    }
}

//_____________________________________________________________________

class ArithmeticDemo {
    public static void playWithArithematic() {
        // Division and remainder
        
        System.out.println(17 / 5);
        System.out.println(17 % 5);
        System.out.println(Math.floorMod(17, 5));
        
        System.out.println(-17 / 5);
        System.out.println(-17 % 5);
        System.out.println(Math.floorMod(-17, 5));
        
        int[] a = { 17, 29 };
        int n = 0;
        System.out.printf("%d %d\n", a[n++], n); 
        n = 0;
        System.out.printf("%d %d\n", a[++n], n);

        // Powers and roots
        System.out.println(Math.pow(10, 9));
        System.out.println(Math.sqrt(1000000));

        // Number conversions
        double x = 42;
        System.out.println(x); // 42.0
        
        float f = 123456789;
        System.out.println(f); // 1.23456792E8
        
        x = 3.75;
        n = (int) x;
        System.out.println(n); // 3
        
        n = (int) Math.round(x); 
        System.out.println(n); // 4
        
        System.out.println('J' + 1); // 75
        char next = (char)('J' + 1); 
        System.out.println(next); // 'K'
        
        n = (int) 3000000000L; 
        System.out.println(n); // -1294967296        
    }
}

//_____________________________________________________________________

class RelationalDemo {
    public static void playWithRelationalOperators() {
        int length = 10;
        int n = 7;
        System.out.println(0 <= n && n < length);
        
        // Short circuit evaluation
        int s = 30;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        n = 0;
        System.out.println(n != 0 && s + (100 - s) / n < 50);
        System.out.println(n == 0 || s + (1 - s) / n >= 50);
        
        int time = 7;
        System.out.println(time < 12 ? "am" : "pm");
    }
}

//_____________________________________________________________________

class StringDemo {
    public static void playWithStrings() {
        String location = "Java";
        String greeting = "Hello " + location;
        System.out.println(greeting);
        int age = 42;
        String output = age + " years";
        System.out.println(output);
        
        System.out.println("Next year, you will be " + age + 1); // Error
        System.out.println("Next year, you will be " + (age + 1)); // Ok
        
        String names = String.join(", ", "Peter", "Paul", "Mary");
        System.out.println(names);

		// String is Immutable By Default    
        // location[0] = 'K';

        // To Create Mutable String Use StringBuilder Type
        StringBuilder builder = new StringBuilder();
        for (String id : ZoneId.getAvailableZoneIds()) {
            builder.append(id);
            builder.append(", ");
        }

        String result = builder.toString();
        System.out.println(result.substring(0, 200) + "...");
        System.out.println(result.length());        

        // Substring
        greeting = "Hello, World!";
        location = greeting.substring(7, 12);
        System.out.println(location);

        // Equality testing     
        System.out.println(location.equals("World"));
        System.out.println(location == "World");
        System.out.println(location.equalsIgnoreCase("world"));
        System.out.println("word".compareTo("world"));

        // Converting between numbers and strings
        int n = 42;
        String str = Integer.toString(n, 2);
        System.out.println(str);

        n = Integer.parseInt(str);
        System.out.println(n);
        n = Integer.parseInt(str, 2);
        System.out.println(n);
        double x = Double.parseDouble("3.14"); 
        System.out.println(x);
        
        System.out.println(greeting.toUpperCase());
        System.out.println(greeting); // greeting is not changed
        
        // Unicode
        String javatm = "Java\u2122";
        System.out.println(javatm);
        System.out.println(Arrays.toString(javatm.codePoints().toArray()));
        System.out.println(javatm.length());
        
        String octonions = "\ud835\udd46";
        System.out.println(octonions);
        System.out.println(Arrays.toString(octonions.codePoints().toArray()));
        System.out.println(octonions.length()); // Counts code units, not Unicode code points
    }
}

//_____________________________________________________________________

class InputDemo {
    public static void playWithUserInputs() {
        Scanner in = new Scanner(System.in);
        System.out.println("What is your name?");
        String name = in.nextLine();
        System.out.println("How old are you?");
        if (in.hasNextInt()) {
            int age = in.nextInt();
            System.out.printf("Hello, %s. Next year, you'll be %d.\n", name, age + 1);
        } else {
            System.out.printf("Hello, %s. Are you too young to enter an integer?", name);
        }
    }
}

//_____________________________________________________________________

class ArrayDemo {
    public static void playWithArrays() {
        String[] names = new String[10];
        for (int i = 0; i < names.length / 2; i++) {
            names[i] = "";
        }
        names[0] = "Fred";
        names[1] = names[0];
        System.out.println("names="+Arrays.toString( names ) );
        
        int[] primes = { 17, 19, 23, 29, 31 };
        System.out.println("primes="+Arrays.toString( primes ) );

        int [] primesAgain = new int[] { 2, 3, 5, 7, 11, 13 };
        System.out.println("primesAgain="+Arrays.toString( primesAgain ) );
        // Enhanced For Loop
        int sum = 0;
        for (int n : primes) {
            sum += n;
        }
        System.out.println("sum=" +sum);
    
    	// Home Work!!!
        int[] numbers = primes;
        System.out.println("primes="+Arrays.toString( primes ) );
        System.out.println("numbers="+Arrays.toString( numbers ) );

        numbers[4] = 42;
        System.out.println("primes="+Arrays.toString( primes ) );
        System.out.println("numbers="+Arrays.toString( numbers ) );
    }
}

//_____________________________________________________________________

class ArrayListDemo {
    public static void playWithArrayLists() {
        ArrayList<String> friends = new ArrayList<>();
        friends.add("Peter");
        friends.add("Paul");
        friends.remove(1);
        friends.add(0, "Paul"); // Adds before index 0
        System.out.println("friends=" + friends);
        String first = friends.get(0);
        System.out.println("first=" + first);
        friends.set(1, "Mary");
        for (int i = 0; i < friends.size(); i++) {
            System.out.println(friends.get(i));
        }
	}
}

//_____________________________________________________________________

class TwoDimensionalArrayDemo {
    public static void playWithTwoDimentionalArray() {
        int[][] square = {
                { 16, 3, 2, 13 },
                { 3, 10, 11, 8 },
                { 9, 6, 7, 12 },
                { 4, 15, 14, 1}
            };
        
        // Swap two rows
        int[] temp = square[0];
        square[0] = square[1];
        square[1] = temp;
        System.out.println(Arrays.deepToString(square));
        
        int n = 5;
        int[][] triangle = new int[n][];
        for (int i = 0; i < n; i++) {
            triangle[i] = new int[i + 1];
            triangle[i][0] = 1;
            triangle[i][i] = 1;
            for (int j = 1; j < i; j++) {
                triangle[i][j] = triangle[i - 1][j - 1] + triangle[i - 1][j];
            }
        }
        for (int r = 0; r < triangle.length; r++) {
            for (int c = 0; c < triangle[r].length; c++) {
                System.out.printf("%4d", triangle[r][c]);
            }
            System.out.println();
        }
        for (int[] row : triangle) {
            for (int element : row) {
               System.out.printf("%4d", element);
            }
            System.out.println();
        }
    }
}

//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________
//_____________________________________________________________________

public class JavaFundamentals {
	public static void main( String [] args ) {
		System.out.println("\n\nFunction : playWithNumbers");
		NumberDemo.playWithNumbers();

		System.out.println("\n\nFunction : playWithVariables");
		VariableDemo.playWithVariables();

		System.out.println("\n\nFunction : playWithArithematic");
		ArithmeticDemo.playWithArithematic();

		System.out.println("\nFunction : playWithRelationalOperators");
		RelationalDemo.playWithRelationalOperators();

		System.out.println("\nFunction : playWithStrings");
		StringDemo.playWithStrings();

		// System.out.println("\nFunction : playWithUserInputs");
		// InputDemo.playWithUserInputs();

		System.out.println("\nFunction : playWithArrays");
		ArrayDemo.playWithArrays();

		System.out.println("\nFunction : playWithArrayLists");
		ArrayListDemo.playWithArrayLists();

		System.out.println("\nFunction : playWithTwoDimentionalArray");
		TwoDimensionalArrayDemo.playWithTwoDimentionalArray();

		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
		// System.out.println("\nFunction : ");
	}
}

/*
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
https://codebunk.com/b/7631100607916/
*/

